<?php 
	require 'conexion.php';
	$aidii = $_POST['aidi'];echo $aidii;
	$conexion = new mysqli("localhost","root","","vydslab");
	mysqli_query($conexion,"UPDATE $tabbadges set P1='1', CP='1' where ID='$aidii'");
	mysqli_query($conexion,"UPDATE $tabesta set COINS=10 where ID='$aidii'");
	header('Location: ../perfil.php');
?>
<?php
    $host = "localhost";
    $user = "root";
    $pw = "";
    $db = "vydslab";
    $tabregis = "registro";
    $tabbadges = "badges";
    $tabesta = "estadistica";
    $tabgift = "tarjetas";
    $verdad = 1;
    $falso = 0;
?>
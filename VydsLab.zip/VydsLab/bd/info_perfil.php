<?php 
	
	require("conexion.php");
	$conexion = mysqli_connect($host,$user,$pw,$db);
	$userid1 = $_SESSION['id'];
	$comprobar1 = mysqli_query($conexion,"SELECT * FROM $tabesta WHERE ID = '".$userid1."'");
    $row1 = mysqli_fetch_array($comprobar1);

    $comprobar2 = mysqli_query($conexion,"SELECT * FROM $tabbadges WHERE ID = '".$userid1."'");
    $row2 = mysqli_fetch_array($comprobar2);

    $coins = $row1['COINS'];
    $lastconex = $row1['LASTCONEX'];
    $racha = $row1['RACHA'];

    $_SESSION['p1'] = $row2['P1'];
    $_SESSION['cp'] = $row2['CP'];

?>
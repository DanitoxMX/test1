<?php

    require("conexion.php");
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $compro = strlen($email) * strlen($pass);

    if($compro > 0){
    session_start();
    $conexion = mysqli_connect($host,$user,$pw,$db);
    $comprobar = mysqli_query($conexion,"SELECT * FROM $tabregis WHERE EMAIL = '".$email."' AND PASS =  '".$pass."'");

        if(@mysqli_num_rows($comprobar)  == 1){
            $comprobar = mysqli_query($conexion,"SELECT * FROM $tabregis WHERE EMAIL = '".$email."'");
            $row = mysqli_fetch_array($comprobar);
            $_SESSION['id'] = $row['ID'];
            $_SESSION['usuario'] = $row['NOMBRE'];
            $_SESSION['apellido'] = $row['APELLIDO'];
            $_SESSION['usa'] = $row['EMAIL'];
            $_SESSION['prem'] = $row['PREM'];
            $_SESSION['acerca'] = $row['ACERCA'];   
            $_SESSION['login'] = TRUE;
            $aidi = $_SESSION['id'];
            $fecha = date("d/m/Y");
            $dia = date("d");

            mysqli_query($conexion,"UPDATE $tabesta SET LASTCONEX='$fecha',DIA='$dia' WHERE ID='$aidi'");

            mysqli_close($conexion);

            echo '<script language="javascript">
            alert("Iniciando Sesión");
            window.history.go(-1);
            </script>';	
            header('Location: ../perfil.php');
        }else{
            echo '<script language="javascript">
            alert("Correo o contraseña incorrectos");
            window.history.go(-1);
            </script>';	
        }
    }else{
        echo '<script language="javascript">
        alert("Rellene los campos");
        window.history.go(-1);
        </script>';	
    }

?>
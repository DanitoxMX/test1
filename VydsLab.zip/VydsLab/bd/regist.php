<?php
require("conexion.php");

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    $codigo = $_POST['codigo'];
    session_start();
    $reqlen = strlen($nombre) * strlen($apellido) * strlen($email) * strlen($pass1) * strlen($pass2);

    if($reqlen > 0){
        if($pass1 === $pass2){
            $conexion = new mysqli("localhost","root","","vydslab");
            if (mysqli_connect_errno()){
                echo "Problemas al conectar con el servidor";
            }
            $comprobar = mysqli_query($conexion,"SELECT * FROM $tabregis WHERE EMAIL = '".$email."'");
            if(mysqli_num_rows($comprobar)  == 1){
				$_SESSION['error'] = TRUE;
				echo '<script language="javascript">
                alert("El correo ya está registrado");
                window.history.go(-1);
                </script>';	
			}else{
                $comprocodigo = mysqli_query($conexion,"SELECT * FROM $tabgift WHERE codigos = '".$codigo."'");
                if(mysqli_num_rows($comprocodigo)  == 1){
                    mysqli_query($conexion,"INSERT INTO $tabregis (NOMBRE,APELLIDO,EMAIL,PASS,PREM) VALUES ('$nombre','$apellido','$email','$pass1','$verdad')");
                    mysqli_query($conexion, "DELETE FROM $tabgift WHERE codigos='$codigo'");
                }else{
                    mysqli_query($conexion,"INSERT INTO $tabregis (NOMBRE,APELLIDO,EMAIL,PASS) VALUES ('$nombre','$apellido','$email','$pass1')");
                }

                $fecha = date("d/m/Y");
                $dia = date("d");

                $comprobar = mysqli_query($conexion,"SELECT * FROM $tabregis WHERE EMAIL = '".$email."'");
                $row = mysqli_fetch_array($comprobar);
                $_SESSION['id'] = $row['ID'];
                $userid = $_SESSION['id'];
				$_SESSION['usuario'] = $row['NOMBRE'];
                $_SESSION['usa'] = $row['EMAIL'];
                $_SESSION['prem'] = $row['PREM'];
                $_SESSION['apellido'] = $row['APELLIDO'];
                $_SESSION['acerca'] = $row['ACERCA'];  
                $_SESSION['login'] = TRUE;
                
                mysqli_query($conexion, "INSERT INTO $tabbadges (ID) VALUES ('$userid')");

                mysqli_query($conexion, "INSERT INTO $tabesta (ID,LASTCONEX,RACHA,DIA) VALUES ('$userid','$fecha','1','$dia')");

                mysqli_close($conexion);
                echo '<script language="javascript">
                alert("Registro exitoso");
                </script>';
                header ('Location: ../perfil.php');
            }
        }else{
            echo '<script language="javascript">
            alert("Las contraseñas no son iguales");
            window.history.go(-1);
            </script>';
        }
    }else{
        echo '<script language="javascript">
        alert("Rellene todos los campos");
        window.history.go(-1);
        </script>';
    }
?>
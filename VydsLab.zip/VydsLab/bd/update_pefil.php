<?php

	require("conexion.php");
session_start();
	$upnombre = $_POST['nombre'];
	$upapellido = $_POST['apellido'];
	$uppassante = $_POST['passante'];
	$uppass1 = $_POST['pass1'];
	$uppass2 = $_POST['pass2'];
	$updesc = $_POST['acerca'];
	$aidi = $_POST['aidi'];
	

	$compro = strlen($upnombre) * strlen($upapellido) * strlen($uppassante) * strlen($uppass2) * strlen($uppass1) * strlen($updesc);


		$conexion = mysqli_connect($host,$user,$pw,$db);
		
		$compro1 = strlen($upnombre) * strlen($upapellido);
		$compro11 = strlen($uppassante) * strlen($uppass2) * strlen($uppass1) * strlen($updesc);
		$compro2 = strlen($uppassante) * strlen($uppass2) * strlen($uppass1);
		$compro22 = strlen($upnombre) * strlen($upapellido) * strlen($updesc);

		$compro3 = strlen($updesc);
		$compro33 = strlen($upnombre) * strlen($upapellido) * strlen($uppassante) * strlen($uppass2) * strlen($uppass1);
		if ($compro1 > $compro11) {
			#editamos parte de nombre y apellido
			mysqli_query($conexion, "UPDATE $tabregis set NOMBRE='$upnombre', APELLIDO='$upapellido' where ID='$aidi'");
			$_SESSION['usuario'] = $upnombre;
			$_SESSION['apellido'] = $upapellido;
			header('Location: ../perfil.php');

		}elseif ($compro3 > $compro33) {
			#editaos parte de contraseñas
			mysqli_query($conexion, "UPDATE $tabregis set ACERCA='$updesc' where ID='$aidi'");
				$_SESSION['acerca'] = $updesc;
			
			header('Location: ../perfil.php');
		}elseif ($compro2 > $compro22) {
			#editamos parte de descripcion
			$contracompro = mysqli_query($conexion,"SELECT PASS FROM $tabregis WHERE PASS='$uppassante' and ID='$aidi'");
			
			if(@mysqli_num_rows($contracompro)  == 1){
				if ($uppass1 == $uppass2) {
				
				mysqli_query($conexion, "UPDATE $tabregis set PASS='$uppass1' where ID='$aidi'");
				$_SESSION['acerca'] = $updesc;
				header('Location: ../perfil.php');

				}else{
					echo '<script language="javascript">alert("Las contraseñas nuevas no coinciden");window.history.go(-1);</script>';	
				}
			}else{
				echo '<script language="javascript">alert("Tu contraseña anterior no coincide");window.history.go(-1);</script>';	
			}
			
		}else{
			echo '<script language="javascript">alert("No ingresaste los datos correctamente");window.history.go(-1);</script>';	
		}
		mysqli_close($conexion);
?>
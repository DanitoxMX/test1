<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML'></script>
   
 <script  type = "text / x-mathjax-config" > 
  MathJax . Hub . Config ({ tex2jax :  { inlineMath :  [[ '$' , '$' ],  [ '\\ (' , '\\)' ]]}}); 
</script> 
	
  
  <script>
      $(document).ready(function() {
    $('select').material_select();
  });
         
  </script>
  <script src="js/init.js"></script>
  <script src="js/circuitos.js"></script>
  
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Circuitos RC</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'edi-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
    <center>
      <p style="font-family: 'Bubblegum Sans', cursive; font-size: 30px;">Ejemplo de un circuito RC</p>
        <img src="img/ed/rc1.png" width="40%">
        <br><br>
        <ul id="tabs-swipe-demo" class="tabs tabs-fixed-width red-text">
          <li class="tab col s3" id="sec1"><a class="sec1" href="#test-swipe-1">Carga (posición 1)</a></li>
          <li class="tab col s3" id="sec2"><a  href="#test-swipe-2">Descarga (posición 2)</a></li>
          
        </ul>
        <div id="test-swipe-1" class="col s12">
            <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rcp1.png" width="30%">
            <form id="ingresa_datos" action="bd/badgesp1.php" method="POST">
              <div class="row">
                <div class="input-field col s3">
                  <input id="voltaje" type="text" class="validate" required>
                  <label for="last_name">Voltaje</label>
                </div>
                <div class="input-field col s2">
                  <input id="resistencia" type="text" class="validate">
                  <label for="last_name">Resistencia $\mathrm\Omega$</label>
                </div>
                <div class="input-field col s1">
                  <select id="resisteV">
                     <option value="3" >Ohms</option>
                     <option value="1">Kohms</option>
                     <option value="2">Mohms</option>
                  </select>
                </div>
                <div class="input-field col s2">
                  <input id="capacitor" type="text" class="validate">
                  <label for="last_name">Capacitor</label>
                </div>
                <div class="input-field col s1">
                  <select id="capaciV">
                     <option value="4" >C</option>
                     <option value="1">mC</option>
                     <option value="2">$\mu$C</option>
                     <option value="3">nC</option>
                  </select>
                </div>
                <div class="col s3">
                  <a class="btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;" onclick="resolver()">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución: </p>
                

                <div id="prueba"></div>
                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p>
                  <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><msub><mn id="v1"><mi>V</mi><mi>s</mi></mn></msub><mfenced><mrow><mn>1</mn><mo>-</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc1"><mi>R</mi><mi>C</mi></mn></mrow></msup></mrow></mfenced></math>
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a class="btn-flat" id="displayNone" onclick="MosOcul2(<?php echo $esPrem ?>)">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: none;" id="caja">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $-V_s + v_R + v_C = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_R = RC \left( \frac{\mathrm{d}v_C}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mn id="rc2"></mn><mfenced><mfrac><mrow><mi mathvariant="normal">d</mi><msub><mi>v</mi><mi>C</mi></msub></mrow><mrow><mi>d</mi><mi>t</mi></mrow></mfrac></mfenced><mo>=</mo><msub><mn id="v2"></mn></msub><mo>-</mo><msub><mi>v</mi><mi>C</mi></msub></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>v</mi><mi>c</mi></msub></mrow><mrow><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn id="v3"></mn></msub></mrow></mfrac><mo>=</mo><mo>-</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi></mrow><mrow><mn id="rc3"></mn></mrow></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_0^{v_c}\frac{dv_c}{v_c-V_s}$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>v</mi><mi>c</mi></msub></mrow><mrow><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn id="v4"></mn></msub></mrow></mfrac><mo>=</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><mi>u</mi></mrow><mi>u</mi></mfrac><mo>=</mo><mi>ln</mi><mi>u</mi><msubsup><mo>&#x23D0;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mo>=</mo><mi>ln</mi><mo>(</mo><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn id="v5"></mn></msub><mo>)</mo><msubsup><mo>&#x23D0;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup></math>
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{RC}$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mo>-</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi></mrow><mrow><mn id="rc4"></mn></mrow></mfrac><mo>=</mo><mo>-</mo><mfrac><mn>1</mn><mrow><mn id="rc5"></mn></mrow></mfrac><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mi>u</mi><mi>d</mi><mi>x</mi><mo>=</mo><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc6"></mn></mrow></mfrac><msubsup><mo>&#x23D0;</mo><mn>0</mn><mi>t</mi></msubsup></math>
                  </p>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Nos queda: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mo>(</mo><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mi>V</mi><mi>s</mi></msub><mo>)</mo><mo>-</mo><mi>ln</mi><mo>(</mo><mn>0</mn><mo>-</mo><msub><mi>V</mi><mi>s</mi></msub><mo>)</mo><mo>=</mo><mo>-</mo><mfenced open="[" close="]"><mrow><mfrac><mi>t</mi><mrow><mi>R</mi><mi>C</mi></mrow></mfrac><mo>-</mo><mfrac><mn>0</mn><mrow><mi>R</mi><mi>C</mi></mrow></mfrac></mrow></mfenced></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mfenced><mfrac><mrow><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn id="v6"></mn></msub></mrow><mrow><mo>-</mo><msub><mn id="v7"></mn></msub></mrow></mfrac></mfenced><mo>=</mo><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc7"></mn></mrow></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $v_c$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mrow><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn id="v8"></mn></msub></mrow><mrow><mo>-</mo><msub><mn id="v9"></mn></msub></mrow></mfrac><mo>=</mo><msup><mi>e</mi><mrow><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc8"></mn></mrow></mfrac></mrow></msup></math>
                    <br><br><br>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><mo>-</mo><msub><mn id="v10"></mn></msub><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc9"></mn></mrow></msup><mo>+</mo><msub><mn id="v11"></mn></msub></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><msub><mn id="v12"></mn></msub><mfenced><mrow><mn>1</mn><mo>-</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc10"></mn></mrow></msup></mrow></mfenced></math>
                  </p>
                  
                  <form action="bd/badgesp1.php" method="POST" style="display: block;">
                    <input type="" name="aidi" style="display: none;" value=" <?php echo $userid1 ?>">    
                    <?php 
                      if (isset($_SESSION['login'])) {
                        if ($_SESSION['p1']==1) {
                          echo '<p class="center-align" style="font-family: \'Bubblegum Sans\', cursive; font-size: 18px;">Felicidades obtuviste una medalla de Piedra I</p>
                          <button class="btn waves-effect waves-light" type="submit" name="action">Reclamar Medalla</button>';
                        }
                      }

                    ?>
                  </form>
                  <p></p>
                </div>
              </div>
            </div>  <!--CARGA -->
        </div>
        <div id="test-swipe-2" class="col s12">
          <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rcp2.png" width="30%">
            <form action="">
              <div class="row">
                <div class="input-field col s3">
                  <input id="voltaje2" type="text" class="validate">
                  <label for="last_name">Voltaje inicial</label>
                </div>
                <div class="input-field col s2">
                  <input id="resistencia2" type="text" class="validate">
                  <label for="last_name">Resistencia $\mathrm\Omega$</label>
                </div>
                <div class="input-field col s1">
                  <select id="resisteV2">
                     <option value="3" >Ohms</option>
                     <option value="1">Kohms</option>
                     <option value="2">Mohms</option>
                  </select>
                </div>
                <div class="input-field col s2">
                  <input id="capacitor2" type="text" class="validate">
                  <label for="last_name">Capacitor</label>
                </div>
                <div class="input-field col s1">
                  <select id="capaciV2">
                     <option value="4" >C</option>
                     <option value="1">mC</option>
                     <option value="2">$\mu$C</option>
                     <option value="3">nC</option>
                  </select>
                </div>
                <div class="col s3">
                  <a class="waves-effect waves-light btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;" onclick="resolver2()">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución:</p>

                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p>
                  <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><msub><mn id="v21"><mi>V</mi><mi>s</mi></mn></msub><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc21"><mi>R</mi><mi>C</mi></mn></mrow></msup></math>
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a class="btn-flat" id="displayNone" onclick="MosOcul1(<?php echo $esPrem ?>)">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: block;" id="caja2">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $v_R + v_C = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_R = RC \left( \frac{\mathrm{d}v_C}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mn id="rc22"></mn><mfenced><mfrac><mrow><mi mathvariant="normal">d</mi><msub><mi>v</mi><mi>C</mi></msub></mrow><mrow><mi>d</mi><mi>t</mi></mrow></mfrac></mfenced><mo>=</mo><mo>-</mo><msub><mi>v</mi><mi>C</mi></msub></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><msub><mn id="v22"></mn></msub><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>v</mi><mi>c</mi></msub></mrow><msub><mi>v</mi><mi>c</mi></msub></mfrac><mo>=</mo><mo>-</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi></mrow><mrow><mn id="rc23"></mn></mrow></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_0^{v_c}\frac{dv_c}{v_c-V_s}$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><msub><mn id="v23"></mn></msub><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>v</mi><mi>c</mi></msub></mrow><msub><mi>v</mi><mi>c</mi></msub></mfrac><mo>=</mo><msubsup><mo>&#x222B;</mo><msub><mn id="v24"></mn></msub><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><mi>u</mi></mrow><mi>u</mi></mfrac><mo>=</mo><mi>ln</mi><mi>u</mi><msubsup><mo>&#x23D0;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mo>=</mo><mi>ln</mi><mo>(</mo><msub><mi>v</mi><mi>c</mi></msub><mo>)</mo><msubsup><mo>&#x23D0;</mo><msub><mn id="v25"></mn></msub><msub><mi>v</mi><mi>c</mi></msub></msubsup></math>
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{RC}$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mo>-</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi></mrow><mrow><mn id="rc24"></mn></mrow></mfrac><mo>=</mo><mo>-</mo><mfrac><mn>1</mn><mrow><mn id="rc25"></mn></mrow></mfrac><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mi>u</mi><mi>d</mi><mi>x</mi><mo>=</mo><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc26"></mn></mrow></mfrac><msubsup><mo>&#x23D0;</mo><mn>0</mn><mi>t</mi></msubsup></math>
                  </p>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Nos queda: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mo>(</mo><msub><mi>v</mi><mi>c</mi></msub><mo>)</mo><mo>-</mo><mi>ln</mi><mo>(</mo><msub><mi>V</mi><mi>s</mi></msub><mo>)</mo><mo>=</mo><mo>-</mo><mfenced open="[" close="]"><mrow><mfrac><mi>t</mi><mrow><mi>R</mi><mi>C</mi></mrow></mfrac><mo>-</mo><mfrac><mn>0</mn><mrow><mi>R</mi><mi>C</mi></mrow></mfrac></mrow></mfenced></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mfenced><mfrac><msub><mi>v</mi><mi>c</mi></msub><msub><mn id="v26"></mn></msub></mfrac></mfenced><mo>=</mo><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc27"></mn></mrow></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $v_c$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><msub><mi>v</mi><mi>c</mi></msub><msub><mn id="v27"></mn></msub></mfrac><mo>=</mo><msup><mi>e</mi><mrow><mo>-</mo><mfrac><mi>t</mi><mrow><mn id="rc28"></mn></mrow></mfrac></mrow></msup></math>
                    <br><br><br>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><msub><mn id="v28"></mn></msub><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc29"></mn></mrow></msup></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>v</mi><mi>c</mi></msub><mo>=</mo><msub><mn id="v29"></mn></msub><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mo>/</mo><mn id="rc210"></mn></mrow></msup></math>
                  </p>
                </div>
              </div>
            </div>  <!--DESCARGA -->
        </div>
        <div id="noesPrem" style="display: none;">
          <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
            <p class="center-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Actualízate a Premium para ver los pasos</p>
          </div>
        </div>
    </center>
    </div>
  </div>



  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>

</body>
</html>
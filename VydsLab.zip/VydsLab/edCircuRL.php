<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <script src="js/circuitos.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML'></script>
   
 <script  type = "text / x-mathjax-config" > 
  MathJax . Hub . Config ({ tex2jax :  { inlineMath :  [[ '$' , '$' ],  [ '\\ (' , '\\)' ]]}}); 
</script> 
	  <script>
      $(document).ready(function() {
        $('select').material_select();
      });       
  </script>

</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Circuitos RL</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'edi-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
    <center>
      <p style="font-family: 'Bubblegum Sans', cursive; font-size: 30px;">Ejemplo de un circuito RL</p>
        <img src="img/ed/rl1.png" width="40%">
        <br><br>
        <ul id="tabs-swipe-demo" class="tabs tabs-fixed-width red-text">
          <li class="tab col s3"><a class="active" href="#test-swipe-1">Carga (posición 1)</a></li>
          <li class="tab col s3"><a  href="#test-swipe-2">Descarga (posición 2)</a></li>
          
        </ul>
        <div id="test-swipe-1" class="col s12">
            <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rlp1.png" width="30%">
            <form action="">
              <div class="row">
                <div class="input-field col s3">
                  <input id="voltaje" type="text" class="validate" required>
                  <label for="last_name">Voltaje</label>
                </div>
                <div class="input-field col s2">
                  <input id="resistencia" type="text" class="validate">
                  <label for="last_name">Resistencia $\mathrm\Omega$</label>
                </div>
                <div class="input-field col s1">
                  <select id="resisteV">
                     <option value="3" >Ohms</option>
                     <option value="1">Kohms</option>
                     <option value="2">Mohms</option>
                  </select>
                </div>
                <div class="input-field col s2">
                  <input id="bobina" type="text" class="validate">
                  <label for="last_name">Bobina</label>
                </div>
                <div class="input-field col s1">
                  <select id="bobinaV">
                     <option value="4" >H</option>
                     <option value="1">mH</option>
                     <option value="2">$\mu$H</option>
                  </select>
                </div>
                <div class="col s3">
                  <a class="btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;" onclick="resolver21()">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución:</p>

                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p">
                  <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mn id="v1"><msub><mi>I</mi><mn>0</mn></msub></mn><mfenced><mrow><mn>1</mn><mo>-</mo><msup><mi>e</mi><mrow><mo>-</mo><mn id="r1"><mi>R</mi></mn><mo>&#xB7;</mo><mi>t</mi><mo>/</mo><mn id="l1"><mi>L</mi></mn></mrow></msup></mrow></mfenced></math>
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a class="btn-flat" id="displayNone" onclick="MosOcul2(<?php echo $esPrem ?>)">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: none;" id="caja">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $-V_s + v_R + v_l = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_l = L \left( \frac{\mathrm{d}v_l}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi id="l2">L</mi><mfenced><mfrac><mrow><mi mathvariant="normal">d</mi><msub><mi>i</mi><mi>l</mi></msub></mrow><mrow><mi>d</mi><mi>t</mi></mrow></mfrac></mfenced><mo>=</mo><mn id="v2"></mn><mo>-</mo><msub><mi>i</mi><mi>l</mi></msub><mi id="r2">R</mi></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><mn>0</mn><msub><mi>i</mi><mi>l</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>i</mi><mi>l</mi></msub></mrow><mrow><mn id="v3"></mn><mo>-</mo><msub><mi>i</mi><mi>l</mi></msub><mi id="r3">R</mi></mrow></mfrac><mo>=</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi></mrow><mi id="l3">L</mi></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_0^{i_l}\frac{dv_c}{V_s-i_lR}$</p>
                  <p>
                    \begin{equation*}
                    \int_0^{i_l}\frac{di_c}{V_s-i_lR}=\int_0^{i_l}\frac{du}{u}= \frac{1}{R}\ln u \arrowvert_0^{i_l}= -\frac{1}{R}\ln(v_c-V_s)\arrowvert_0^{i_l}
                    \end{equation*}
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{L}$</p>
                  <p>
                    \begin{equation*}
                    \int_0^t\frac{dt}{L} = \frac{1}{L}\int_0^t u dx = \frac{t}{L} \arrowvert_0^{t}
                    \end{equation*}
                  </p>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Nos queda:</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mo>(</mo><mn id="v4"></mn><mo>-</mo><msub><mi>i</mi><mi>s</mi></msub><mi id="r4">R</mi><mo>)</mo><mo>-</mo><mi>ln</mi><mo>(</mo><mn id="v5"></mn><mo>-</mo><mn>0</mn><mo>)</mo><mo>=</mo><mo>-</mo><mfenced open="[" close="]"><mrow><mfrac><mi>t</mi><mrow><mi id="l4">L</mi></mrow></mfrac><mo>-</mo><mfrac><mn>0</mn><mrow><mi id="l5">L</mi></mrow></mfrac></mrow></mfenced></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mfenced><mfrac><mrow><mn id="v6"></mn><mo>-</mo><msub><mi>i</mi><mi>l</mi></msub><mi id="r5">R</mi></mrow><mn id="v7"></mn></mfrac></mfenced><mo>=</mo><mo>-</mo><mfrac><mrow><mi id="r6">R</mi><mi>t</mi></mrow><mi id="l6">L</mi></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $i_l$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mrow><mn id="v8"></mn><mo>-</mo><msub><mi>i</mi><mi>l</mi></msub><mi id="r7">R</mi></mrow><mn id="v9"></mn></mfrac><mo>=</mo><msup><mi>e</mi><mrow><mo>-</mo><mfrac><mrow><mi id="r8">R</mi><mi>t</mi></mrow><mi id="l7">L</mi></mfrac></mrow></msup></math>
                    <br><br><br>

                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mfrac><mn id="v10"></mn><mi id="r10">R</mi></mfrac><mo>-</mo><mfrac><mn id="v11"></mn><mi id="r9">R</mi></mfrac><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r11">R</mi><mo>/</mo><mi id="l8">L</mi></mrow></msup></math>
                    <br><br><br>

                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mi id="v12">V</mi><mo>-</mo><mi id="v13">V</mi><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r12">R</mi><mo>/</mo><mi id="l9">L</mi></mrow></msup></math>

                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mi id="v14">V</mi><mfenced><mrow><mn>1</mn><mo>-</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r13">R</mi><mo>/</mo><mi id="l10">L</mi></mrow></msup></mrow></mfenced></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mi id="v15">V</mi><mfenced><mrow><mn>1</mn><mo>-</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r14">R</mi><mo>/</mo><mi id="l11">L</mi></mrow></msup></mrow></mfenced></math>
                  </p>
                </div>
              </div>
            </div>
        </div>
        <div id="test-swipe-2" class="col s12">
          <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rlp2.png" width="30%">
            <form action="">
              <div class="row">
                <div class="input-field col s3">
                  <input id="voltaje2" type="text" class="validate" required>
                  <label for="last_name">Voltaje</label>
                </div>
                <div class="input-field col s2">
                  <input id="resistencia2" type="text" class="validate">
                  <label for="last_name">Resistencia $\mathrm\Omega$</label>
                </div>
                <div class="input-field col s1">
                  <select id="resisteV2">
                     <option value="3" >Ohms</option>
                     <option value="1">Kohms</option>
                     <option value="2">Mohms</option>
                  </select>
                </div>
                <div class="input-field col s2">
                  <input id="bobina2" type="text" class="validate">
                  <label for="last_name">Bobina</label>
                </div>
                <div class="input-field col s1">
                  <select id="bobinaV2">
                     <option value="4" >H</option>
                     <option value="1">mH</option>
                     <option value="2">$\mu$H</option>
                  </select>
                </div>
                <div class="col s3">
                  <a class="btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;" onclick="resolver22()">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución:</p>

                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p>
                  <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mn id="v21"><msub><mi>I</mi><mn>0</mn></msub></mn><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r21">R</mi><mo>/</mo><mi id="l21">L</mi></mrow></msup></math>
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a class="btn-flat" id="displayNone" onclick="MosOcul1(<?php echo $esPrem ?>)">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: none;" id="caja2">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $v_R + v_l = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_l = L \left( \frac{\mathrm{d}i_l}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi id="l22">L</mi><mfenced><mfrac><mrow><mi mathvariant="normal">d</mi><msub><mi>i</mi><mi>l</mi></msub></mrow><mrow><mi>d</mi><mi>t</mi></mrow></mfrac></mfenced><mo>=</mo><mo>-</mo><msub><mi>i</mi><mi>l</mi></msub><mi id="r22">R</mi></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><mi id="v22">V</mi><msub><mi>i</mi><mi>l</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>i</mi><mi>l</mi></msub></mrow><msub><mi>i</mi><mi>l</mi></msub></mfrac><mo>=</mo><mo>-</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><mi>t</mi></msubsup><mfrac><mrow><mi>d</mi><mi>t</mi><mi id="r23">R</mi></mrow><mi id=l23>L</mi></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_{I_0}^{i_l}\frac{di_l}{i_l}$</p>
                  <p>
                    \begin{equation*}
                    \int_{I_0}^{i_l}\frac{di_l}{i_l}=\int_{I_0}^{i_l}\frac{du}{u}= \ln u \arrowvert_{I_0}^{i_l}= \ln(i_l)\arrowvert_{I_0}^{i_l}
                    \end{equation*}
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{L}$</p>
                  <p>
                    \begin{equation*}
                    -\int_0^t\frac{dtR}{L} = -\frac{R}{L}\int_0^t u dx = -\frac{tR}{L} \arrowvert_0^{t}
                    \end{equation*}
                  </p>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Nos queda:</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mo>(</mo><msub><mi>i</mi><mi>l</mi></msub><mo>)</mo><mo>-</mo><mi>ln</mi><mo>(</mo><mn id="v23"></mn><mo>)</mo><mo>=</mo><mo>-</mo><mfrac><mi id="r24">R</mi><mi id="l24">L</mi></mfrac><mfenced open="[" close="]"><mi>t</mi></mfenced></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mi>ln</mi><mfenced><mfrac><msub><mi>i</mi><mi>l</mi></msub><mi id="v24">V</mi></mfrac></mfenced><mo>=</mo><mo>-</mo><mfrac><mrow><mi id="r25">R</mi><mi>t</mi></mrow><mi id="l25">L</mi></mfrac></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $i_l$</p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><msub><mi>i</mi><mi>l</mi></msub><mi id="v25">V</mi></mfrac><mo>=</mo><msup><mi>e</mi><mrow><mo>-</mo><mfrac><mrow><mi id="r26">R</mi><mi>t</mi></mrow><mi id="l26">L</mi></mfrac></mrow></msup></math>
                    <br><br><br>

                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mi id="v26">V</mi><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r27">R</mi><mo>/</mo><mi id="l27">L</mi></mrow></msup></math>
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msub><mi>i</mi><mi>l</mi></msub><mo>=</mo><mi id="v27">V</mi><mo>&#xB7;</mo><msup><mi>e</mi><mrow><mo>-</mo><mi>t</mi><mi id="r28">R</mi><mo>/</mo><mi id="l28">L</mi></mrow></msup></math>
                  </p>
                </div>
              </div>
            </div>
        </div>
    </center>
    </div>
  </div>

<script type="text/javascript">

function serie()
{
  var numero1 = document.getElementById('num1').value;
  var numero2 = document.getElementById('num2').value;
  var resulta = parseFloat(numero1) + parseFloat(numero2) + " Ω";
  resul.value = resulta;
}

function paralelo()
{
  var numer1 = document.getElementById('nume1').value;
  var numer2 = document.getElementById('nume2').value;
  var resultado = (1/((1/numer1) + (1/numer2)))+" Ω";
  result.value = resultado;
}

function clean()
{
document.getElementById("datos").reset();
}

</script>


  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML'></script>
   
 <script  type = "text / x-mathjax-config" > 
  MathJax . Hub . Config ({ tex2jax :  { inlineMath :  [[ '$' , '$' ],  [ '\\ (' , '\\)' ]]}}); 
</script> 
	
  
  <script>
      $(document).ready(function() {
    $('select').material_select();
  });
         
  </script>
  <script src="js/init.js"></script>
  <script src="js/circuitos.js"></script>
  
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Tipos de ED</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'edi-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
      <center>
        <ul id="tabs-swipe-demo" class="tabs tabs-fixed-width">
          <li class="tab col s3"><a class="active" href="#test-swipe-1">Separable</a></li>
          <li class="tab col s3"><a  href="#test-swipe-2">Homogénea</a></li>
          <li class="tab col s3"><a  href="#test-swipe-3">Bernoulli</a></li>
        </ul>
        <div id="test-swipe-1" class="col s12">
          
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Una ecuación diferencial de primer orden de la forma:</p>
          <p style="font-size:20px;">
            $\frac{dy}{dx} = g(x) \cdot h(y)$
          </p>
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Se dice que es separable o que tiene variables separables.</p>
        
          <div id="cajaT1" style="display: block;">
            <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Por ejemplo:</p>
            <p>
              $\frac{dy}{dx} = y^2 \cdot x \cdot e^{3x+4y}$ &nbsp &nbsp y &nbsp &nbsp $\frac{dy}{dx} = y + \sin{x}$
            </p>
            <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Son respectivamente, separable y no separable. En la primera ecuación podemos factorizar &nbsp &nbsp $f\left(x,y\right) = y^2 \cdot x \cdot e^{3x+4y}$ &nbsp &nbsp como</p>
            <p>
              $\frac{dy}{dx} = y^2 \cdot x \cdot e^{3x+4y}  =  \left(x \cdot e^{3x}\right)\left(y^2 \cdot e^{4y}\right)$
            </p>
            <p>$g(x) = \left(x \cdot e^{3x}\right)$</p>
            <p>$h(y) = \left(y^2 \cdot e^{4y}\right)$</p>
            <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Pero en la segunda ecuación no hay forma de expresar $a y + \sin{x}$ como un producto de una función de $x$ por una función de $y$</p>
          </div>
        </div>
        <div id="test-swipe-2" class="col s12">
          
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Una ecuación diferencial homogénea de primer orden de la forma:</p>
          <p style="font-size:20px;">$\frac{dy}{dx} = F \left(\frac{y}{x}\right)$ &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp $(1)$</p>
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Si sustituimos: </p>
          <p style="font-size:20px;">
            $v = \frac{y}{x}$ &nbsp &nbsp &nbsp $y=vx$ &nbsp &nbsp &nbsp $\frac{dy}{dx} = v +x\frac{dv}{dx}$
          </p>
           <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">de la ecuación $(1)$ transformamos a variables separables:</p>
          <p style="font-size:20px;">
            $v +x\frac{dv}{dx} = F(\frac{y}{x})$ &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp $(2)$
          </p>
           <p style="font-size:20px;">
            $x\frac{dv}{dx} = F(v) - v $
          </p>
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Así que toda ecuación diferencial homogénea puede reducirse a un problema de integración por medio de la sustitución indicada en la ecuación $(2)$</p>
        </div>
        <div id="test-swipe-3" class="col s12">
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Una ecuación diferencial de Bernoulli de primer orden de la forma:</p>
          <p style="font-size:20px;">$\frac{dy}{dx} = P(x)y = Q(x)y^2$ &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp $(1)$</p>
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Si $n=0$ o $n=1$ no se puede realizar</p>
          <p style="font-size:20px;">$v = y^{1-n}$</p>
          <p style="font-family: 'Bubblegum Sans', cursive; font-size:20px;" class="left-align">Transformando la ecuación ${1}$ queda</p>
          <p style="font-size:20px;">$\frac{dy}{dx} + (1-n) \cdot P(x)v = (1-n) \cdot Q(x) $</p>
        </div>

        <div id="noesPrem" style="display: none;">
          <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
            <p class="center-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Actualízate a Premium para ver los pasos</p>
          </div>
        </div>

      </center>
    </div>
  </div>



  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>

</body>
</html>
<head>
	 <link rel="stylesheet" type="text/css" href="css/tema.css">
</head>
<body>
	<h3 ><a href="simul-home.php" class="#ef5350-text" id="titleright">Ecuaciones Diferenciales</a></h3>
    <ul>
		<a href="edCircuRC.php" class="teal-text"><li id="subtright">Circuitos RC</li></a>
        
        <a href="edCircuRL.php" class="teal-text"><li id="subtright">Circuitos RL</li></a>
        
        <a href="edTipos.php" class="teal-text"><li id="subtright">Tipos de Ecuaciones Diferenciales</li></a>
        
        
    </ul>
</body>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
	
  <!-- CODIGO PARA QUE APARESCAN LOS SELECT-->
  <script type = "text/javascript" src = "https://code.jquery.com/jquery-2.1.1.min.js"></script> 
  <script>
         $(document).ready(function() {
            $('select').material_select();
         });
      </script>

</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Números Aleatorios</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'elect-temas.php';
      ?>
    </div>

    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
    <center><p id="subti"><a href="#" onclick="Materialize.toast('Debajo tenemos un tutorial, échale un ojo!',4000)" class="black-text">Código de Colores de Resistencias</a></p></center>
    <p align="justify">Dados los colores de una resistencia,calcula cuánto es su valor y tolerancia.</p><br>
    <div>
   
<form>
  <div class="input-field col s12 m6">
  <select NAME="tensSelect" onChange="setTens(this)">
  <option > Negro
  <option> Marron
  <option> Rojo
  <option> Naranja
  <option> Amarillo
  <option> Verde
  <option> Azul
  <option> Violeta
  <option> Gris
  <option> Blanco</select> <label>1ra Banda</label><br>
  </div>

  <div class="input-field col s12 m6">
  <select NAME="onesSelect" onChange="setOnes(this)" >
  <option > Negro
  <option> Marron
  <option> Rojo
  <option> Naranja
  <option> Amarillo
  <option> Verde
  <option> Azul
  <option> Violeta
  <option> Gris
  <option> Blanco</select>  <label>2da Banda</label><br></div>

  <div class="input-field col s12 m6">
  <SELECT NAME="multiplierSelect" onChange="setMult(this)" >
  <option > Negro
  <option> Marron
  <option> Rojo
  <option> Naranja
  <option> Amarillo
  <option> Verde
  <option> Azul
  <option> Violeta
  <option> Gris
  <option> Blanco</select><label>3ra Banda</label><br></div>

  <div class="input-field col s12 m6">
  <SELECT NAME="toleranceSelect" onChange="setTol(this)" >
  <option > Dorado
  <option> Plateado
  <option> Ninguno</SELECT> <label>4ta Banda</label><br></div>

</form>
</div>

<script type="text/javascript">
// Crea un arreglo con los valores de los multiplicadores
var multiplier = new Array()
multiplier[0] = 0
multiplier[1] = 1
multiplier[2] = 2
multiplier[3] = 3
multiplier[4] = 4
multiplier[5] = 5
multiplier[6] = 6
multiplier[7] = 7
multiplier[8] = 8
multiplier[9] = 9
multiplier[10] = -1
multiplier[11] = -2

// Crea un arreglo con los valores de tolerancia
var tolerance = new Array()
tolerance[0] = "+/-5%"
tolerance[1] = "+/-10%"
tolerance[2] = "+/-20%"

// Formatea valores altos en Kilo y Mega ohms
function format(ohmage) {
  if (ohmage >= 1e6) {
    ohmage /= 1e6
    return "" + ohmage + " Mohms"
  } else {
    if (ohmage >= 1e3) {
      ohmage /= 1e3
      return "" + ohmage + " Kohms"
    } else {
      return "" + ohmage + " ohms"
    }
  }
}

// Calcula los valores de resistencia y tolerancia
function calcOhms() {
  var form = document.forms[0]
  var d1 = form.tensSelect.selectedIndex
  var d2 = form.onesSelect.selectedIndex
  var m = form.multiplierSelect.selectedIndex
  var t = form.toleranceSelect.selectedIndex
  var ohmage = (d1 * 10) + d2
  ohmage = eval("" + ohmage + "e" + multiplier[m])
  ohmage = format(ohmage)
  var tol = tolerance[t]
  document.forms[1].result.value = ohmage + " , " + tol
}

// Pre-Carga todas las imágenes en el cache para que corra rápido.
var colorList = "Negro,Azul,Marron,Dorado,Gris,Verde,Ninguno,Naranja,Rojo,Plateado,Violeta,Blanco,Amarillo"
var colorArray = colorList.split(",")
var imageDB = new Array()
for (i = 0; i < colorArray.length; i++) {
  imageDB[colorArray[i]] = new Image(21,182)
  imageDB[colorArray[i]].src = "bandasColores/" + colorArray[i] + ".gif"
}

function setTens(choice) {
  var tensColor = choice.options[choice.selectedIndex].text
  document.tens.src = imageDB[tensColor].src
  calcOhms()
}
function setOnes(choice) {
  var onesColor = choice.options[choice.selectedIndex].text
  document.ones.src = imageDB[onesColor].src
  calcOhms()
}
function setMult(choice) {
  var multColor = choice.options[choice.selectedIndex].text
  document.mult.src = imageDB[multColor].src
  calcOhms()
}
function setTol(choice) {
  var tolColor = choice.options[choice.selectedIndex].text
  document.tol.src = imageDB[tolColor].src
  calcOhms()
}

  var form = document.forms[0]
  var tensDigit = form.tensSelect.selectedIndex
  var tensColor = form.tensSelect.options[tensDigit].text
  var onesDigit = form.onesSelect.selectedIndex
  var onesColor = form.onesSelect.options[onesDigit].text
  var multDigit = form.multiplierSelect.selectedIndex
  var multColor = form.multiplierSelect.options[multDigit].text
  var tolDigit = form.toleranceSelect.selectedIndex
  var tolColor = form.toleranceSelect.options[tolDigit].text

var table ="<TABLE class='center-align'>"
table += "<TR><TH>Valor de la Resistencia:</TH><TD><FORM><INPUT TYPE='text' NAME='result' SIZE=20 placeholder='Resultado'></FORM>"
table +="</TD></TR><TR><TD COLSPAN=2 >"
table +="<IMG SRC='bandasColores/resleft.gif' WIDTH=127 HEIGHT=182 class='center-align'>" +
      "<IMG SRC='bandasColores/" + tensColor + ".gif' NAME='tens' WIDTH=21 HEIGHT=182>"+
      "<IMG SRC='bandasColores/" + onesColor + ".gif' NAME='ones' WIDTH=21 HEIGHT=182>"+
      "<IMG SRC='bandasColores/" + multColor + ".gif' NAME='mult' WIDTH=21 HEIGHT=182>"+
      "<IMG SRC='bandasColores/spacer.gif' WIDTH=17 HEIGHT=182>"+
      "<IMG SRC='bandasColores/" + tolColor + ".gif' NAME='tol' WIDTH=21 HEIGHT=182>"+
      "<IMG SRC='bandasColores/resright.gif' WIDTH=127 HEIGHT=182>"
table += "</TD></TR></TABLE>"
document.write(table)

</script>

      </div>
  </div>

   
  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        
<script type="text/javascript">
  function compro3() {
      
      var v1 = document.getElementById('ejer31').value;
      var n = document.getElementById('n').value;
      var a = document.getElementById('a').value;
      var c = document.getElementById('c').value;
      var m = document.getElementById('m').value;

      var res = new Array();
      for (var i = 0; i < n; i++) {
        res[i] = (a*v1+33)%m;
        v1 = res[i];
        res[i] = (v1/(m-1)).toFixed(4);
      }
     document.getElementById('res3').value = res;
        
      
    }
</script>
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
</body>
</html>
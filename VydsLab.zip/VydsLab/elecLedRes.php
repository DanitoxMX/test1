<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <!-- CODIGO PARA QUE APARESCAN LOS SELECT-->
  </script> 
  <script>
         $(document).ready(function() {
            $('select').material_select();
         });
      </script>

      <!-- parte para ver los resultados-->
  <script type "text/javascript" src="pgm/ledResCalculatorSp.js"></script>

</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Números Aleatorios</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'elect-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
    <center><p id="subti"><a href="#" onclick="Materialize.toast('Debajo tenemos un tutorial, échale un ojo!',4000)" class="black-text">Resistencias para leds</a></p></center>


  <div >
        <form name="input">
        <strong><legend>Datos para el cálculo</legend></strong>
        <div class="input-field col s12 m6">
        <label for="tension">Tensión: </label><br><br>
        <select name="tension" onChange="calcoloRes()">
          <option value="2.4"> 2,4V
          <option value="3"> 3V
          <option value="3.6"> 3,6V
          <option value="4.5"> 4,5V
          <option value="5" selectED> 5V
          <option value="6"> 6V
          <option value="7.2"> 7,2V
          <option value="9"> 9V
          <option value="12"> 12V
          <option value="13.6"> 13,6V
          <option value="15"> 15V
          <option value="19"> 19V
          <option value="24"> 24V
          <option value="36"> 36V
        </select><br> </div>

        <div class="input-field col s12 m6">
        <label for="colorLeds">Color de los leds: </label><br><br>
        <select name="colorLeds" onChange="calcoloRes()">
          <option value="led-red" selectED> rojo / red (1.8V )
          <option value="led-green"> verde / green (2.1V )
          <option value="led-yellow"> amarillo / yellow (2.1V ) 
          <option value="led-white"> blanco / white (3.6V )
          <option value="led-blue"> azul / blue (3.6V )
        </select><br></div>

        <div class="input-field col s12 m6">
        <label for="numLeds">Cantidad de leds: </label><br><br>
        <select name="numLeds" onChange="calcoloRes()">
          <option value="1" selectED> 1
          <option value="2"> 2
          <option value="3"> 3
          <option value="4"> 4
          <option value="5"> 5
          <option value="6"> 6
        </select><br></div> 
        
        <div class="input-field col s12 m6">
        <label for="current">Corriente: </label><br><br>
        <select name="current" onChange="calcoloRes()">
          <option value="0.005"> 5&nbsp;mA
          <option value="0.010"> 10&nbsp;mA
          <option value="0.015"> 15&nbsp;mA         
          <option value="0.020" selectED> 20&nbsp;mA  
          <option value="0.025"> 25&nbsp;mA         
          <option value="0.030"> 30&nbsp;mA
          <option value="0.040"> 40&nbsp;mA
          <option value="0.050"> 50&nbsp;mA
          <option value="0.060"> 60&nbsp;mA
          <option value="0.070"> 70&nbsp;mA
          <option value="0.080"> 80&nbsp;mA   
          <option value="0.090"> 90&nbsp;mA             
          <option value="0.100"> 100&nbsp;mA
          <option value="0.150"> 150&nbsp;mA          
          <option value="0.200"> 200&nbsp;mA
          <option value="0.250"> 250&nbsp;mA          
          <option value="0.300"> 300&nbsp;mA          
        </select></div>
        </form>
      </div>
      <script>document.write(table)</script> 
    </div>
  </div>


  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="I am a tooltip">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        

  
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
	
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Números Aleatorios</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'elect-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
    <center><p id="subti"><a href="#" onclick="Materialize.toast('Debajo tenemos un tutorial, échale un ojo!',4000)" class="black-text">Resistencias Serie/Paralelo</a></p></center>

    <p align="justify"><strong>Conexión de resistencias en Serie:</strong><br><br>Para identificar una conexión en serie de resistencias simplemente tenemos que fijarnos en que la salida de una de las resistencias esté conectada directamente a la entrada de la siguiente.<br>Para sumar resistencias en serie simplemente tenemos que sumar el valor de cada una de ellas, obteniendo así el valor de la resistencia equivalente tal y como indica la siguiente expresión matemática:<br><br><img src="imagElectronica/Formula-de-resistencias-en-serie.png" alt="">
    <div align="center"><img src="imagElectronica/serie.png" ></div><br><br>

    <form id="datos">
    <legend>Datos para el cálculo en Serie</legend> 
    <input type="text" id="num1" placeholder=" R1 en ohms"> 
    <input type="text" id="num2" placeholder=" R2 en ohms" ><br><br>
    <center><a class="waves-effect waves-light red lighten-1 btn"  onclick="serie()">Calcular</a>
    <a class="waves-effect waves-light red lighten-1 btn"  onclick="clean()">Borrar Datos</a></center>
    <input type="text" id="resul" placeholder=" Resultado" >
    <br><br><br>


      <p align="justify"><strong>Conexión de resistencias en paralelo</strong> <br><br>
       
      La conexión en paralelo de resistencias se caracteriza porque los terminales de entrada de cada uno de los resistores están conectados entre sí. <br>
      Debido a esto, por todas las resistencias pasa el mismo voltaje, es decir, tienen la misma caída de tensión. Esto se debe a que los extremos de cada una de la resistencias están conectados al mismo punto del circuito y por lo tanto, comparten la misma tensión.
      </p><br><img src="imagElectronica/Formula-de-resistencias-en-paralelo.png" alt=""><br><br> <div align="center"><img src="imagElectronica/paralelo.png" ></div><br><br>
    
      <legend>Datos para el cálculo en Paralelo</legend> 
      <input type="text" id="nume1" placeholder=" R1 en ohms"> 
      <input type="text" id="nume2" placeholder=" R2 en ohms" ><br><br>
      <center><a class="waves-effect waves-light red lighten-1 btn"  onclick="paralelo()">Calcular</a>

      <a class="waves-effect waves-light red lighten-1 btn"  onclick="clean()">Borrar Datos</a></center>
      <input type="text" id="result" placeholder=" Resultado" >
      <br><br><br>
    </form>



    </div>
  </div>

<script type="text/javascript">

function serie()
{
  var numero1 = document.getElementById('num1').value;
  var numero2 = document.getElementById('num2').value;
  var resulta = parseFloat(numero1) + parseFloat(numero2) + " Ω";
  resul.value = resulta;
}

function paralelo()
{
  var numer1 = document.getElementById('nume1').value;
  var numer2 = document.getElementById('nume2').value;
  var resultado = (1/((1/numer1) + (1/numer2)))+" Ω";
  result.value = resultado;
}

function clean()
{
document.getElementById("datos").reset();
}

</script>


  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        
<script type="text/javascript">
  function compro3() {
      
      var v1 = document.getElementById('ejer31').value;
      var n = document.getElementById('n').value;
      var a = document.getElementById('a').value;
      var c = document.getElementById('c').value;
      var m = document.getElementById('m').value;

      var res = new Array();
      for (var i = 0; i < n; i++) {
        res[i] = (a*v1+33)%m;
        v1 = res[i];
        res[i] = (v1/(m-1)).toFixed(4);
      }
     document.getElementById('res3').value = res;
        
      
    }
</script>
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 

  <meta name="description" content="least.js 2 - Random and Responsive HiDPI jQuery Gallery based on HTML5 and CSS3">
  <!-- Responsive viewport for smartphone devices -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <!-- least.js 2 CSS file -->
  <link href="src/css/least.min.css" rel="stylesheet" />
	
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Números Aleatorios</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
		</div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'elect-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
      <center><p id="subti"><a href="#" onclick="Materialize.toast('Debajo tenemos un tutorial, échale un ojo!',4000)" class="black-text">Simulaciones en Proteus</a></p></center><br>
    <!--<p align="justify">OBJETIVO:<br>Análisis de circuitos resistivos aplicando la ley de Ohm.<br><br>
    INTRODUCCION:<br>
    Unas de las herramientas más utilizadas en la electrónica son las resistencias cuya principal función es limitar el paso de la corriente en un circuito, físicamente están elaboradas de carbono o metal. Su unidad de medición es el ohmio (Ω).
    </p><br>
  -->
   <!-- <div align="center"><label>Simulación de la practica en Proteus</label><br>
    <img src="simuProteus/simul1.png" width="700px" height="400px"></div>-->

        <!-- Least Gallery -->
        <section id="least">
            
            <!-- Least Gallery: Fullscreen Preview -->
            <div class="least-preview"></div>
            
            <!-- Least Gallery: Thumbnails -->
            <ul class="least-gallery">

                  <li>
                    <a href="src/media/big/proteus.png" title="Programa" data-subtitle="View Picture">
                        <img src="src/media/big/proteus.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 1 || Element with data-caption ||-->
                <li>
                    <a href="src/media/big/simul1.png" title="Resistencias" data-subtitle="View Picture">
                        <img src="src/media/big/simul1.png" alt="Alt Image Text" />
                    </a>
                </li>
                
                
                <!-- 2 || Element with data-caption as href-attribute ||-->-->
                <li>
                    <a href="src/media/big/sim2.png" title="Capacitores" data-subtitle="View Picture">
                        <img src="src/media/big/sim2.png" alt="Alt Image Text" />
                    </a>
                </li>
                
                <!-- 3 -->
                <li>
                    <a href="src/media/big/sim3.png" title="Led/Capacitor" data-subtitle="View Picture">
                        <img src="src/media/big/sim3.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 4 -->
                <li>
                    <a href="src/media/big/sim4.png" title="Diodo" data-subtitle="View Picture">
                        <img src="src/media/big/sim4.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 5 -->
                <li>
                    <a href="src/media/big/sim5.png" title="Diodo Zener" data-subtitle="View Picture">
                        <img src="src/media/big/sim5.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 6 -->
                <li>
                    <a href="src/media/big/sim6.png" title="Transformador" data-subtitle="View Picture">
                        <img src="src/media/big/sim6.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 7 -->
                <li>
                    <a href="src/media/big/sim7.png" title="Media Onda" data-subtitle="View Picture">
                        <img src="src/media/big/sim7.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 8 -->
                <li>
                    <a href="src/media/big/sim8.png" title="Puente diodos" data-subtitle="View Picture">
                        <img src="src/media/big/sim8.png" alt="Alt Image Text" />
                    </a>
                </li>

                <!-- 9 -->
                
        </section>
        <!-- Least Gallery end -->

        <!-- jQuery library -->
        <script src="src/js/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- least.js library -->
        <script src="src/js/libs/least/least.min.js"></script>

        <script>
            $(document).ready(function(){
                $('.least-gallery').least();
            });
        </script>
        
        <!-- &&& START CODE &&& ONLY FOR PERSONAL USE: PLEASE DON'T EMBED THIS CODE INTO YOUR PAGE -->
        <script>
            /* Google Analytics */
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-16040332-11', 'leastjs.com');
            ga('set', 'anonymizeIp', true);
            ga('send', 'pageview');
        </script>
          <!-- &&& END CODE &&& ONLY FOR PERSONAL USE: PLEASE DON'T EMBED THIS CODE INTO YOUR PAGE-->


<!----                          -->

    </div>
  </div>

  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        
<script type="text/javascript">
  function compro3() {
      
      var v1 = document.getElementById('ejer31').value;
      var n = document.getElementById('n').value;
      var a = document.getElementById('a').value;
      var c = document.getElementById('c').value;
      var m = document.getElementById('m').value;

      var res = new Array();
      for (var i = 0; i < n; i++) {
        res[i] = (a*v1+33)%m;
        v1 = res[i];
        res[i] = (v1/(m-1)).toFixed(4);
      }
     document.getElementById('res3').value = res;
        
      
    }
</script>
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
</body>
</html>
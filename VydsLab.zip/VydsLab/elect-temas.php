<head>
	 <link rel="stylesheet" type="text/css" href="css/tema.css">
</head>
<body>
	<h3 ><a href="simul-home.php" class="#ef5350-text" id="titleright">Electrónica Básica</a></h3>
    <ul>
		<a href="elecColorRes.php" class="teal-text"><li id="subtright">Código de colores resistencias</li></a>
        
        <a href="elecOHM.php" class="teal-text"><li id="subtright"> Ley de Ohm</li></a>
        
        <a href="elecResis.php" class="teal-text"><li id="subtright">Resistencias Serie/Paralelo</li></a>
        
        <a href="elecCapa.php" class="teal-text"><li id="subtright">Capacitores Serie/Paralelo</li></a>
        
        <a href="elecLedRes.php" class="teal-text"><li id="subtright">Resistencias para LED</li></a>
        
        <a href="elecSimul.php" class="teal-text"><li id="subtright">Simulaciones de Proteus</li></a>
        
    </ul>
</body>
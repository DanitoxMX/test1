<?php
  session_start();
  $userr = "<li><a class=\"modal-trigger\" href=\"#modal2\" id=\"fuente\" ><i class=\"material-icons left\" >account_circle</i>Iniciar Sesión</a></li>";
  
  $btnregistro = "<a class=\"waves-effect waves-light red lighten-2 btn-large\" id=\"btnregistro\" href=\"registro.php\">Registrate</a>";

  if(isset($_SESSION['login'])){
    $userr = "<li><a class=\"dropdown-button\" id=\"fuente\" data-activates=\"dropdown1\"><i class=\"material-icons left\" >account_circle</i>".$_SESSION['usuario']."<i class=\"material-icons right\">arrow_drop_down</i></a></li>";
    $acusuario = $_SESSION['usuario'];
    $userid1 = $_SESSION['id'];
    $esPrem = $_SESSION['prem']; 
    $btnregistro = "<a class=\"waves-effect waves-light red lighten-2 btn-large\" id=\"btnregistro\" href=\"perfil.php\">Comienza</a>";

    ///  ------  Premium   ------  ///
    if ($_SESSION['prem'] > 0) {
      $isPremium = "<span class=\"card-title red-text\" id=\"temas\">Usuario Premium</span><img class=\"circle\" src=\"img/user_prem.jpg\" width=\"200px\" height=\"200px\">";
    }else{
      $isPremium = "<span class=\"card-title red-text\" id=\"temas\">Usuario Normal</span><img class=\"circle\" src=\"img/user_norm.jpg\" width=\"200px\" height=\"200px\"><p id=\"contenido\"><a class=\"waves-effect waves-light btn modal-trigger\" href=\"#modalpago\">Conviertete a Premium</a></p>";
    }
    
  }
?>


<head>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <link rel="stylesheet" type="text/css" href="css/index.css">
  
  <script src="js/jquery-3.2.1.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
  <script>
    $(document).ready(function(){
      $('.modal').modal();
    });
  </script>
  
</head>

<nav>
    <div class="nav-wrapper red lighten-1">
      <a href="index.php" class="brand-logo center" id="logo">VydsLab</a>
      <a href="index.php" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">Menú</i></a>
      <ul class="left hide-on-med-and-down">
      <ul id="dropdown1" class="dropdown-content">
        <li><a href="perfil.php" class="red-text">Perfil</a></li>
        <li><a href="bd/cerrar.php" class="red-text">Cerrar Sesión</a></li>
      </ul>
      <?php   
			  echo $userr; 
			?>
      
        <!--<li><a class="modal-trigger" href="#modal1" id="fuente" ><i class="material-icons left" >account_circle</i>Iniciar Sesión</a></li> -->
      </ul>
      <ul class="right hide-on-med-and-down">
        <li><a class="modal-trigger" href="#modal1" id="fuente"><i class="material-icons left" >view_module</i>Materias</a></li>
	    </ul>
      <!-- Smartphone -->
      <ul class="side-nav" id="mobile-demo"> 
        <li><a class="modal-trigger" href="#modal1">Iniciar Sesión</a></li>
        <li><a class="modal-trigger" href="#modal1">Materias</a></li>
      </ul>
    </div>

    
</nav>

<div id="modal1" class="modal">
    <div class="modal-content">
      <center>
      <div class="row">
        <div class="col s6">
          <a href="elecColorRes.php"><h5 id="titulo">Electrónica Básica</h5></a>
          <br>
          <img class="circle" src="img/electronica.jpg" width="100px" height="100px">
        </div> 
        <div class="col s6">
          <a href="edCircuRC.php"><h5 id="titulo">Ecuaciones Diferenciales</h5></a>
          <br>
          <img class="circle" src="img/ed.png" width="100px" height="100px">
        </div>
      </div>
      <div class="row">
        <div class="col s6">
          <a href=""><h5 id="titulo">Métodos Numéricos</h5></a>
          <br>
          <img class="circle" src="img/metonum.png" width="100px" height="100px">
        </div>
        <div class="col s6">
          <a href="simul-home.php" id="temas"><h5 id="titulo">Simulación</h5></a>
          <br>
          <img class="circle" src="img/simula.jpg" width="100px" height="100px">
        </div>
      </div>
      </center>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Cerrar</a>
    </div>
  </div>
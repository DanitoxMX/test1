<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>VydsLab</title>

  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

  	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/registro.css">

	<link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet">

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/scrol.js"></script>

</head>
<body>

  <?php 
  include 'header-nav.php';
  ?>

	<!-- Presentación -->
	<div class="row"> 
		<div class="col s12 #ef5350 red lighten-2 z-depth-3" id="fondo" ><br><br><br>
      <span id="eslogan" class="white-text"><center>Practica y Fortalece tus conocimientos</center>
      	<br>
      	<center>
				<?php
					echo $btnregistro;
				?>
				<!--
				<a class="waves-effect waves-light red lighten-2 btn-large" id="btnregistro" href="registro.php">Registrate</a> -->
				</center>
      	</span>
      <br><br>
		</div>
  </div>
   <!-- FIN Presentación --> 	

  <!-- Tabs -->
 	<div class="row" id="menu-tabs">
    <div class="col s12">
      <ul class="tabs">
	      <li class="tab col s3"><a class="sec1" href="" id="submenu">Electrónica Básica</a></li>
	      <li class="tab col s3"><a class="sec2" href="" id="submenu">Ecuaciones Diferenciales</a></li>
	      <li class="tab col s3"><a class="sec3" href="" id="submenu">Métodos Numéricos</a></li>
	      <li class="tab col s3"><a class="sec4" href="" id="submenu">Simulación</a></li>
      </ul>
   	</div>
  </div>
  <!-- FIN Tabs -->


  <div class="row">
    <div class="col s12" id="sec-1">
      <div class="col s12 m4" id="left-menu">
        <br>
        	<a href=""><center><h5 id="titulo">Electrónica Básica</h5></a>
          <br>
        	<img class="circle" src="img/electronica.jpg" width="100px" height="100px">
        	</center>	
      </div>
      <div class="col s12 m8" id="limite"><br>
		    <table>
		      <tbody>
		        <tr>
		          <td><a href="elecColorRes.php" id="temas1">Código de colores de resistencias</a></td>
		          <td><a href="elecOHM.php"  id="temas1">Ley de Ohm</a></td>
		          <td><a href="elecResis.php" id="temas1">Resistencias Serie/Paralelo</a></td>
		        </tr>
		        <tr>
		          <td><a href="elecCapa.php" id="temas1">Capacitores Serie/Paralelo</a></td>
		          <td><a href="elecLedRes.php" id="temas1">Calculadora de resistencias para LED</a></td>
		          <td><a href="elecSimul.php" id="temas1">Simulaciones de Proteus</a></td>
		        </tr>
		      </tbody>
		    </table>
      </div>
    </div>
  </div>

<div class="row">
	<center><div class="col s12 red lighten-2 center"></div></center>
</div>

<div class="row">
        	<div class="col s12" id="sec-2"></div>
        		<div class="col s12 m4" id="left-menu">
        		<br>
        		<center>
        		<a href=""><h5 id="titulo">Ecuaciones Diferenciales</h5></a>
        		<br>
        		<img class="circle" src="img/ed.png" width="100px" height="100px">
        		</center>	
        		</div>
	   	<div class="col s12 m8" id="limite"><br>

		<table>
		        <tbody>
		          <tr>
							<td><a href="edCircuRC.php" id="temas1">Circuitos RC</a></td>
							<td><a href="edCircuRL.php"  id="temas1">Circuitos RL</a></td>
							<td><a href="edTipos.php" id="temas1">Tipos de ecuaciones diferenciales</a></td>       
		          </tr>
		        </tbody>
		</table>
            
        		</div>
	 </div>

         
<div class="row">
	<center><div class="col s12 red lighten-2 center"></div></center>
</div>

<div class="row">
        	<div class="col s12" id="sec-3"></div>
        		<div class="col s12 m4" id="left-menu">
        		<br>
        		<center>
        		<a href=""><h5 id="titulo">Métodos Numéricos</h5></a>
        		<br>
        		<img class="circle" src="img/metonum.png" width="100px" height="100px">
        		</center>	
        		</div>
	   	<div class="col s12 m8" id="limite"><br>

		<table>
		        <tbody>
		          <tr>
		            <td><a href="" id="temas1">Interpolación</a></td>
		            
		          </tr>
		        </tbody>
		</table>
            
        		</div>
	 </div>

<div class="row">
	<center><div class="col s12 red lighten-2 center"></div></center>
</div>

<div class="row">
        	<div class="col s12" id="sec-4"></div>
        		<div class="col s12 m4" id="left-menu">
        		<br>
        		<center>
        		<a href="simul-home.php" id="temas"><h5 id="titulo">Simulación</h5></a>
        		<br>
        		<img class="circle" src="img/simula.jpg" width="100px" height="100px">
        		</center>	
        		</div>
	   	<div class="col s12 m8" id="limite"><br>

		<table>
		        <tbody>
		          <tr>
		            <td><a href="sim1.php" id="temas1">Números Aleatorios</a></td>

		          </tr>
		        </tbody>
		</table>
            
        		</div>
	 </div>
<br><br>
	 
  <?php 
    include 'footer-nav.php';  //  Nav del Footer
	?>

				<div id="modal2" class="modal">
          <div class="modal-content">
					<form action="bd/login.php" method="POST">
            <center>
              <h4 id="modaltitu">Nos alegra que vuelvas :D</h4>
              <p id="modaltexto"  class="center-align">Sabíamos que regresarías, sigue disfrutando de nuestra web</p>
              <div class="row">
                <div class="input-field col s12 l6 push-l3">
                  <input id="email" type="email" class="validate" name="email">
                  <label for="email" data-error="ingrese un correo valido">Email</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12 l6 push-l3">
                  <input id="password" type="password" class="validate" name="pass">
                  <label for="password">Contraseña</label>
                </div>
              </div>
              <button class="btn waves-effect waves-light red lighten-1" type="submit" name="action">Iniciar Sesión
                <i class="material-icons right">send</i>
              </button>
            </center>
					</form>
          </div>
          <div class="modal-footer">
            <a class="modal-action modal-close waves-effect btn-flat">Cerrar</a>
          </div>
        </div>
  
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
	
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  
  <script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML'></script>
   
 <script  type = "text / x-mathjax-config" > 
  MathJax . Hub . Config ({ tex2jax :  { inlineMath :  [[ '$' , '$' ],  [ '\\ (' , '\\)' ]]}}); 
</script> 
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  <script>
    function calc() {
      var x = parseFloat(document.getElementById('voltaje').value);
      document.getElementsByClassName("kaka").innerHTML = x;
    }
  </script>
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
  <?php 
  $miVariable =  "\'frac{t}{RC}";
  //$variablePHP = ("<script>document.write(variablejs)</script>" + 2.2);
  //$variablePHP2 = $variablePHP+1;
  ?>
  <div class="row"> 
    <div class="col s12 #ef5350 z-depth-3" id="fondo1"><br><br>
      <center><span id="eslogan" class="white-text"><a href="simul-home.php" class="white-text">Circuitos RC</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br><br>
    </div>
  </div>

  <div class="row"> <!--  Resumen y Temas -->
    <div class="col l3 hide-on-med-and-down" id="columnaleft">  <!--  Columna de Temas -->     
      <?php 
        include 'elect-temas.php';
      ?>
    </div>
    <div class="col s12 m12 l9" id="columnaright">  <!--  Columna de Resumen -->
      <center>
        <p style="font-family: 'Bubblegum Sans', cursive; font-size: 30px;">Ejemplo de un circuito RC</p>
        <img src="img/ed/rc1.png" width="50%">
        <br><br>
        <ul id="tabs-swipe-demo" class="tabs tabs-fixed-width red-text">
          <li class="tab col s3"><a class="active" href="#test-swipe-1">Carga (posición 1)</a></li>
          <li class="tab col s3"><a  href="#test-swipe-2">Descarga (posición 2)</a></li>
          
        </ul>
        <div id="test-swipe-1" class="col s12">
            <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rcp1.png" width="30%">
            <form action="">
              <div class="row">
                <div class="input-field col s3">
                  <input id="voltaje" type="text" class="validate">
                  <label for="last_name">Voltaje</label>
                </div>
                <div class="input-field col s3">
                  <input id="last_name" type="text" class="validate">
                  <label for="last_name">Resistencia</label>
                </div>
                <div class="input-field col s3">
                  <input id="last_name" type="text" class="validate">
                  <label for="last_name">Capacitor</label>
                </div>
                <div class="col s3">
                  <a class="waves-effect waves-light btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;" onclick="calc()">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución:</p>
                <p>$v_c$</p><p id="aqui"><?php $variablePHP = "<script>document.write(variablejs) </script>";echo $esPrem;?></p><p>$\left(1 - e^{-t/RC}\right)$</p>
                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p class="left-align">
                  \begin{equation*}
                  v_c = V_s \left(<?php echo 5 ?> - e^{-t/RC}\right)
                  \end{equation*}
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a href="#">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: block;">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $-V_s + v_R + v_C = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_R = RC \left( \frac{\mathrm{d}v_C}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    \begin{equation*}
                    <?php echo $miVariable ?>
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    \begin{equation*}
                    \int_0^{v_c}\frac{dv_c}{v_c-V_s}=-\int_0^t\frac{dt}{RC}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_0^{v_c}\frac{dv_c}{v_c-V_s}$</p>
                  <p style="font-size: 20px;">
                    <math xmlns="http://www.w3.org/1998/Math/MathML"><msubsup><mo>&#x222B;</mo><mn id="kaka">0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><msub><mi>v</mi><mi>c</mi></msub></mrow><mrow><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mn ></mn></msub></mrow></mfrac><mo>=</mo><msubsup><mo>&#x222B;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mfrac><mrow><mi>d</mi><mi>u</mi></mrow><mi>u</mi></mfrac><mo>=</mo><mo>[</mo><mi>ln</mi><mi>u</mi><msubsup><mo>]</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup><mo>=</mo><mi>ln</mi><mo>(</mo><msub><mi>v</mi><mi>c</mi></msub><mo>-</mo><msub><mi>V</mi><mi>s</mi></msub><mo>)</mo><msubsup><mo>&#x23D0;</mo><mn>0</mn><msub><mi>v</mi><mi>c</mi></msub></msubsup></math>
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{RC}$</p>
                  <p>
                    \begin{equation*}
                    -\int_0^t\frac{dt}{RC} = -\frac{1}{RC}\int_0^t u dx = -\frac{t}{RC} \arrowvert_0^{t}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    \begin{equation*}
                    \ln\left(\frac{v_c-V_s}{-V_s}\right) = - \frac{t}{RC}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $v_c$</p>
                  <p>
                    \begin{equation*}
                    \frac{v_c-V_s}{-V_s} =  e^{- \frac{t}{RC}}
                    \end{equation*}

                    \begin{equation*}
                    v_c =  -V_s \cdot e^{-t/RC} + V_s
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    \begin{equation*}
                    v_c = V_s \left(1 - e^{-t/RC}\right)
                    \end{equation*}
                  </p>
                </div>
              </div>
            </div>
        </div>
        <div id="test-swipe-2" class="col s12">
          <p style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">figura del circuito</p>
            <img src="img/ed/rcp2.png" width="30%">
            <form action="">
              <div class="row">
                <div class="input-field col s3">
                  <input id="last_name" type="text" class="validate">
                  <label for="last_name">Voltaje inicial</label>
                </div>
                <div class="input-field col s3">
                  <input id="last_name" type="text" class="validate">
                  <label for="last_name">Resistencia</label>
                </div>
                <div class="input-field col s3">
                  <input id="last_name" type="text" class="validate">
                  <label for="last_name">Capacitor</label>
                </div>
                <div class="col s3">
                  <a class="waves-effect waves-light btn-large red" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;">Calcular</a>
                </div>
              </div>
            </form>
            
            <!-- SOLUCIONN QUE SE OCULTA -->
            <div class="row">
              <div class="col s10 push-s1 grey lighten-4" style="border-radius: 5px; border: 2px solid #a1a1a1;">
                <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 25px;">Solución:</p>

                <!-- AQUI IRA LA RESPUESTA OFICIAL -->
                <p class="left-align">
                  \begin{equation*}
                  v_c = V_s \cdot e^{-t/RC}
                  \end{equation*}
                </p>

                <p class="right-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 20px;"><a href="#">Mostrar Pasos <i class="material-icons">keyboard_arrow_down</i></a></p>

                <!-- Area que se oculta y deseculta -->
                <div style="display: block;">
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">De la ley de voltaje de Kirchhoff: &nbsp &nbsp $v_R + v_C = 0$ &nbsp &nbsp donde: &nbsp &nbsp $v_R = RC \left( \frac{\mathrm{d}v_C}{dt}\right)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    \begin{equation*}
                    RC \left( \frac{\mathrm{d}v_C}{dt}\right) = - v_C
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Rescribir como una EDO de primer orden de variables separables: &nbsp &nbsp $N(y) \cdot y' = M(x)$</p>
                  <!-- Area que de respuesta -->
                  <p>
                    \begin{equation*}
                    \int_0^{v_c}\frac{dv_c}{v_c}=-\int_0^t\frac{dt}{RC}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Integrar en cada lado de la ecuación:</p> <!-- RESPUESTA PARA CADA INTEGRAL -->
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración por sustitución para &nbsp &nbsp $\int_0^{v_c}\frac{dv_c}{v_c-V_s}$</p>
                  <p>
                    \begin{equation*}
                    \int_0^{v_c}\frac{dv_c}{v_c-V_s}=\int_0^{v_c}\frac{du}{u}= \ln u \arrowvert_0^{v_c}= \ln(v_c)\arrowvert_0^{v_c}
                    \end{equation*}
                  </p><br>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 16px;">Aplicar integración de una constante para &nbsp &nbsp $\int_0^t\frac{dt}{RC}$</p>
                  <p>
                    \begin{equation*}
                    -\int_0^t\frac{dt}{RC} = -\frac{1}{RC}\int_0^t u dx = -\frac{t}{RC} \arrowvert_0^{t}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Aplicar las leyes de los logaritmos: &nbsp &nbsp $log_a\frac{M}{N} = log_a M - log_a N$</p>
                  <p>
                    \begin{equation*}
                    \ln\left(\frac{v_c}{V_s}\right) = - \frac{t}{RC}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Despejar: &nbsp &nbsp $v_c$</p>
                  <p>
                    \begin{equation*}
                    \frac{v_c}{V_s} =  e^{- \frac{t}{RC}}
                    \end{equation*}

                    \begin{equation*}
                    v_c =  V_s \cdot e^{-t/RC}
                    \end{equation*}
                  </p>
                  <div class="row">
                    <center><div class="col s12 #9e9e9e grey center"></div></center>
                  </div>
                  <p class="left-align" style="font-family: 'Bubblegum Sans', cursive; font-size: 18px;">Solución: </p>
                  <p>
                    \begin{equation*}
                    v_c = V_s \cdot e^{-t/RC}
                    \end{equation*}
                  </p>
                </div>
              </div>
            </div>
        </div>
        
      </center><br>
    
      <p>
        Cuando
<math  xmlns = "http://www.w3.org/1998/Math/MathML" > 
  <mi> a </mi> <mo> &#x2260; </mo> <mn> 0 </mn> 
</math>
      </p>
    </div>
  </div>

  <!--Boton flotante debe ir al video -->
  <div class="fixed-action-btn">
    <a class="btn-floating btn-large teal tooltipped" data-position="left" data-delay="50" data-tooltip="Pulsa para ver el tutorial"">
      <i class="large material-icons">play_arrow</i>
    </a>
  </div>
        

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>
        


</body>
</html>
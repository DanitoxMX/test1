$(document).ready(function(){

    var elem1 = document.getElementById('test-swipe-1');
    var posi1 = elem1.getBoundingClientRect();
    var elem2 = document.getElementById('test-swipe-2');
    var posi2 = elem2.getBoundingClientRect();

    $('.sec1').click(function() {
        $('body, html').animate({
            scrollTop: posi1.top + "px"
        }, 1000);
    });

    
    $('.sec2').click(function() {
        $('body, html').animate({
            scrollTop: posi2.top + "px"
        }, 1000);
    });
   
});


function resolver() {
	var voltaje = parseFloat(document.getElementById('voltaje').value);
	var resis = parseFloat(document.getElementById('resistencia').value);
	var mulresis = parseFloat(document.getElementById('resisteV').value);
	if (mulresis==1) {
		resis = resis * 1000;
	} else {
		if (mulresis==2) {
			resis = resis*100000;
		} else {
			if (mulresis==3) {
				resis=resis;
			}
		}
	}


	var capa = parseFloat(document.getElementById('capacitor').value);
	var mulcapa = parseFloat(document.getElementById('capaciV').value);
	if (mulcapa==1) {
		capa = capa * 0.001;
	} else {
		if (mulcapa == 2) {
			capa = capa * 0.000001
		} else {
			if (mulcapa == 3) {
				capa = capa*0.000000001
			} else{
				if (mulcapa==4) {
					capa == capa;
				}
			}
		}
	}

	document.getElementById('v1').innerHTML = voltaje;
	document.getElementById('v2').innerHTML = voltaje;
	document.getElementById('v3').innerHTML = voltaje;
	document.getElementById('v4').innerHTML = voltaje;
	document.getElementById('v5').innerHTML = voltaje;
	document.getElementById('v6').innerHTML = voltaje;
	document.getElementById('v7').innerHTML = voltaje;
	document.getElementById('v8').innerHTML = voltaje;
	document.getElementById('v9').innerHTML = voltaje;
	document.getElementById('v10').innerHTML = voltaje;
	document.getElementById('v11').innerHTML = voltaje;
	document.getElementById('v12').innerHTML = voltaje;
	document.getElementById('rc1').innerHTML = resis*capa;
	document.getElementById('rc2').innerHTML = resis*capa;
	document.getElementById('rc3').innerHTML = resis*capa;
	document.getElementById('rc4').innerHTML = resis*capa;
	document.getElementById('rc5').innerHTML = resis*capa;
	document.getElementById('rc6').innerHTML = resis*capa;
	document.getElementById('rc7').innerHTML = resis*capa;
	document.getElementById('rc8').innerHTML = resis*capa;
	document.getElementById('rc9').innerHTML = resis*capa;
	document.getElementById('rc10').innerHTML = resis*capa;
}

function resolver2() {
	var voltaje = parseFloat(document.getElementById('voltaje2').value);
	var resis = parseFloat(document.getElementById('resistencia2').value);
	var mulresis = parseFloat(document.getElementById('resisteV2').value);
	if (mulresis==1) {
		resis = resis * 1000;
	} else {
		if (mulresis==2) {
			resis = resis*100000;
		} else {
			if (mulresis==3) {
				resis=resis;
			}
		}
	}
	var capa = parseFloat(document.getElementById('capacitor2').value);
	var mulcapa = parseFloat(document.getElementById('capaciV2').value);
	if (mulcapa==1) {
		capa = capa * 0.001;
	} else {
		if (mulcapa == 2) {
			capa = capa * 0.000001
		} else {
			if (mulcapa == 3) {
				capa = capa*0.000000001
			} else{
				if (mulcapa==4) {
					capa == capa;
				}
			}
		}
	}

	document.getElementById('v21').innerHTML = voltaje;
	document.getElementById('v22').innerHTML = voltaje;
	document.getElementById('v23').innerHTML = voltaje;
	document.getElementById('v24').innerHTML = voltaje;
	document.getElementById('v25').innerHTML = voltaje;
	document.getElementById('v26').innerHTML = voltaje;
	document.getElementById('v27').innerHTML = voltaje;
	document.getElementById('v28').innerHTML = voltaje;
	document.getElementById('v29').innerHTML = voltaje;
	document.getElementById('rc21').innerHTML = resis*capa;
	document.getElementById('rc22').innerHTML = resis*capa;
	document.getElementById('rc23').innerHTML = resis*capa;
	document.getElementById('rc24').innerHTML = resis*capa;
	document.getElementById('rc25').innerHTML = resis*capa;
	document.getElementById('rc26').innerHTML = resis*capa;
	document.getElementById('rc27').innerHTML = resis*capa;
	document.getElementById('rc28').innerHTML = resis*capa;
	document.getElementById('rc29').innerHTML = resis*capa;
	document.getElementById('rc210').innerHTML = resis*capa;
}
function MosOcul2(esPrem) {
	var caja = document.getElementById('caja');
	var premi = esPrem;
	var noEs = document.getElementById('noesPrem');
	if (premi > 0) {
		if (caja.style.display == "none") {
		caja.style.display = "block";
		} else {
			caja.style.display = "none";
		}
	} else {
		noEs.style.display = "block";
	}
}
function MosOcul1(esPrem) {
	var caja = document.getElementById('caja2');
	var premi = esPrem;
	var noEs = document.getElementById('noesPrem');
	if (premi > 0) {
		if (caja.style.display == "none") {
		caja.style.display = "block";
		} else {
			caja.style.display = "none";
		}
	} else {
		noEs.style.display = "block";
	}
}
function resolver21() {
	var voltaje = parseFloat(document.getElementById('voltaje').value);
	var resis = parseFloat(document.getElementById('resistencia').value);
	var mulresis = parseFloat(document.getElementById('resisteV').value);
	if (mulresis==1) {
		resis = resis * 1000;
	} else {
		if (mulresis==2) {
			resis = resis*100000;
		} else {
			if (mulresis==3) {
				resis=resis;
			}
		}
	}


	var bobi = parseFloat(document.getElementById('bobina').value);
	var mulbobi = parseFloat(document.getElementById('bobinaV').value);
	if (mulbobi==1) {
		bobi = bobi * 0.001;
	} else {
		if (mulbobi == 2) {
			bobi = bobi * 0.000001
		} else {
			if (mulbobi == 3) {
				bobi = bobi*0.000000001
			} else{
				if (mulbobi==4) {
					bobi == bobi;
				}
			}
		}
	}
	

	document.getElementById('v1').innerHTML = voltaje;
	document.getElementById('v2').innerHTML = voltaje;
	document.getElementById('v3').innerHTML = voltaje;
	document.getElementById('v4').innerHTML = voltaje;
	document.getElementById('v5').innerHTML = voltaje;
	document.getElementById('v6').innerHTML = voltaje;
	document.getElementById('v7').innerHTML = voltaje;
	document.getElementById('v8').innerHTML = voltaje;
	document.getElementById('v9').innerHTML = voltaje;
	document.getElementById('v10').innerHTML = voltaje;
	document.getElementById('v11').innerHTML = voltaje;
	document.getElementById('v12').innerHTML = voltaje;
	document.getElementById('v13').innerHTML = voltaje;
	document.getElementById('v14').innerHTML = voltaje;
	document.getElementById('v15').innerHTML = voltaje;
	document.getElementById('r1').innerHTML = resis;
	document.getElementById('r2').innerHTML = resis;
	document.getElementById('r3').innerHTML = resis;
	document.getElementById('r4').innerHTML = resis;
	document.getElementById('r5').innerHTML = resis;
	document.getElementById('r6').innerHTML = resis;
	document.getElementById('r7').innerHTML = resis;
	document.getElementById('r8').innerHTML = resis;
	document.getElementById('r9').innerHTML = resis;
	document.getElementById('r10').innerHTML = resis;
	document.getElementById('r11').innerHTML = resis;
	document.getElementById('r12').innerHTML = resis;
	document.getElementById('r13').innerHTML = resis;
	document.getElementById('r14').innerHTML = resis;
	document.getElementById('l1').innerHTML = bobi;
	document.getElementById('l2').innerHTML = bobi;
	document.getElementById('l3').innerHTML = bobi;
	document.getElementById('l4').innerHTML = bobi;
	document.getElementById('l5').innerHTML = bobi;
	document.getElementById('l6').innerHTML = bobi;
	document.getElementById('l7').innerHTML = bobi;
	document.getElementById('l8').innerHTML = bobi;
	document.getElementById('l9').innerHTML = bobi;
	document.getElementById('l10').innerHTML = bobi;
	document.getElementById('l11').innerHTML = bobi;
}
function resolver22() {
	var voltaje = parseFloat(document.getElementById('voltaje2').value);
	var resis = parseFloat(document.getElementById('resistencia2').value);
	var mulresis = parseFloat(document.getElementById('resisteV2').value);
	if (mulresis==1) {
		resis = resis * 1000;
	} else {
		if (mulresis==2) {
			resis = resis*100000;
		} else {
			if (mulresis==3) {
				resis=resis;
			}
		}
	}


	var bobi = parseFloat(document.getElementById('bobina2').value);
	var mulbobi = parseFloat(document.getElementById('bobinaV2').value);
	if (mulbobi==1) {
		bobi = bobi * 0.001;
	} else {
		if (mulbobi == 2) {
			bobi = bobi * 0.000001
		} else {
			if (mulbobi == 3) {
				bobi = bobi*0.000000001
			} else{
				if (mulbobi==4) {
					bobi == bobi;
				}
			}
		}
	}
	
	document.getElementById('v21').innerHTML = voltaje;
	document.getElementById('v22').innerHTML = voltaje;
	document.getElementById('v23').innerHTML = voltaje;
	document.getElementById('v24').innerHTML = voltaje;
	document.getElementById('v25').innerHTML = voltaje;
	document.getElementById('v26').innerHTML = voltaje;
	document.getElementById('v27').innerHTML = voltaje;
	document.getElementById('r21').innerHTML = resis;
	document.getElementById('r22').innerHTML = resis;
	document.getElementById('r23').innerHTML = resis;
	document.getElementById('r24').innerHTML = resis;
	document.getElementById('r25').innerHTML = resis;
	document.getElementById('r26').innerHTML = resis;
	document.getElementById('r27').innerHTML = resis;
	document.getElementById('r28').innerHTML = resis;
	document.getElementById('l21').innerHTML = bobi;
	document.getElementById('l22').innerHTML = bobi;
	document.getElementById('l23').innerHTML = bobi;
	document.getElementById('l24').innerHTML = bobi;
	document.getElementById('l25').innerHTML = bobi;
	document.getElementById('l26').innerHTML = bobi;
	document.getElementById('l27').innerHTML = bobi;
	document.getElementById('l28').innerHTML = bobi;

}
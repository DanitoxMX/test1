(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();
    $('.modal-trigger').leanModal();
  }); // end of document ready
})(jQuery); // end of jQuery name space
$(document).ready(function(){

    var elem1 = document.getElementById('sec-1');
    var posi1 = elem1.getBoundingClientRect();
    var elem2 = document.getElementById('sec-2');
    var posi2 = elem2.getBoundingClientRect();
    var elem3 = document.getElementById('sec-3');
    var posi3 = elem3.getBoundingClientRect();
    var elem4 = document.getElementById('sec-4');
    var posi4 = elem4.getBoundingClientRect();

    $('.sec1').click(function() {
        $('body, html').animate({
            scrollTop: posi1.top + "px"
        }, 1000);
    });

    
    $('.sec2').click(function() {
        $('body, html').animate({
            scrollTop: posi2.top + "px"
        }, 1000);
    });

    
    $('.sec3').click(function() {
        $('body, html').animate({
            scrollTop: posi3.top + "px"
        }, 1000);
    });

    
    $('.sec4').click(function() {
        $('body, html').animate({
            scrollTop: posi4.top + "px"
        }, 1000);
    });

    $('.modal-trigger').leanModal();
   
});
/*$(document).ready(function(){

    alert("quibo");
    /*$('.help').click(function() {
        $('body, html').animate({
            scrollTop: '0px'
        }, 1000);
    });

    
/*
    $('a.sec3').click(function(e) {
        e.preventDefault();
        var enlace = $(this).attr('href');

        $('html, body').animate({
        scrollTop: $(enlace).offset().top
        }, 1000);
    });

    $('a.sec4').click(function(e) {
        e.preventDefault();
        var enlace = $(this).attr('href');

        $('html, body').animate({
        scrollTop: $(enlace).offset().top
        }, 1000);
    });
});     */


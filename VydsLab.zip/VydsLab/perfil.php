<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab | Perfil</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
  
  <script src="js/jquery-3.2.1.min.js"></script>

  <link type="text/css" rel="stylesheet" href="css/perfilio.css">

</head>
<body>
  
  <?php 
  include 'header-nav.php';
  include 'bd/info_perfil.php'
  ?>

    <div class="row">	
		    <div class="col s12 #ef5350 z-depth-3" id="fondo1"><br>
            <center><span id="eslogan" class="white-text">
            <a class="white-text">
            <?php
                echo $_SESSION['usuario'];
                echo ' ';
                echo $_SESSION['apellido'];
            ?>
            </a>
            </span>
            <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
            <br>
		    </div>
    </div>

    <center>
      <ul id="tabs-swipe-demo" class="tabs">
        <li class="tab col s2 center-align" id="letra"><a class="active" href="#test-swipe-1">Perfil</a></li>
        <li class="tab col s2 center-align" id="letra"><a href="#test-swipe-2">Medallas</a></li>
      </ul>
      <br>
        <div id="test-swipe-1" class="col s12">  <!-- AREA DE PERFIL -->
          <div class="row">
            <div class="col s10 m10 s12 push-l1 push-m1">
              <div class="row">
                <div class="col l6 s12"> <!-- COLUMNA IZQUIERDA -->
                  
                <div class="row">   <!-- SECCION INFORMACION -->
                  <div class="col s12" >
                    <div class="card" id="carta">
                      <div class="card-content back-text">
                        <span class="card-title left-align red-text" id="temas">Acerca de mí</span>
                        <div class="row">
                          <center><div class="col s12 red center"></div></center>
                        </div>
                        <p class="left-align" id="contenido"><?php echo $_SESSION['acerca']; ?></p><br>
                        <p class="left-align"><a href="#modalmodifica" class="modal-trigger">Editar perfil</a></p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">  <!-- SECCION MEDALLAS -->
                  <div class="col s12">
                    <div class="card" id="carta">
                      <div class="card-content black-text">
                        <span class="card-title left-align red-text" id="temas">Medallas</span>
                        <div class="row">
                          <center><div class="col s12 red lighten-2 center"></div></center>
                        </div>
                        <div class="row">
                          <div class="col s3">
                            <img src="img/piedra.png" alt="" width="70px" height="70px">
                            <p>Piedra <?php echo $_SESSION['cp'] ?>/3</p>
                          </div>
                          <div class="col s3">
                            <img src="img/iron.png" alt="" width="70px" height="70px">
                            <p>Hierro 0/3</p>
                          </div>
                          <div class="col s3">
                            <img src="img/gold.png" alt="" width="70px" height="70px">
                            <p>Oro 0/3</p>
                          </div>
                          <div class="col s3">
                            <img src="img/diamante.png" alt="" width="70px" height="70px">
                            <p>Diamante 0/3</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                  <div class="row">   <!-- SECCION VYDSCOINS -->
                    <div class="col s12">
                      <div class="card" id="carta">
                        <div class="card-content back-text">
                          <span class="card-title left-align red-text" id="temas">VydsCoins</span>
                          <div class="row">
                            <center><div class="col s12 red lighten-2 center"></div></center>
                          </div>
                          <p class="left-align" id="contenido">Gana VydsCoins descubriendo easter egs dentro de nuestra web, si descubres todos participas en una rifa mensual para ser usuario premium.</p>
                          <p id="puntosSize">Puntos: <?php echo $coins; ?> / 1000</p>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                <div class="col l6 s12"> <!-- COLUMNA DERECHA -->

                  <div class="row">   <!-- SECCION PREMIUM -->
                    <div class="col s12">
                      <div class="card" id="carta">
                        <div class="card-content back-text">
                          <?php 
                            echo $isPremium;
                          ?>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="row">   <!-- SECCION ESTADISTICA -->
                    <div class="col s12">
                      <div class="card" id="carta">
                        <div class="card-content back-text">
                          <span class="card-title left-align red-text" id="temas">Estadisticas</span>
                          <div class="row">
                            <center><div class="col s12 red lighten-2 center"></div></center>
                          </div>
                          <p class="left-align" id="contenido">Fecha de ingreso: <?php echo $lastconex; ?></p>
                          <p class="left-align" id="contenido">Racha de días: <?php echo $racha; ?></p>
                        </div>
                      </div>
                    </div>
                  </div>


                </div>
              </div>
            </div>
          </div>
        </div>

        <div id="test-swipe-2" class="col s12">   <!-- AREA DE MEDALLAS -->
          <div class="row">
            <div class="col l10 m10 s12 push-l1 push-m1">

              <div class="row">
                <div class="col s3"><img src="img/piedra.png" alt="" width="100px" height="100px"></div>
                <div class="col s3"><img src="img/iron.png" alt="" width="100px" height="100px"></div>
                <div class="col s3"><img src="img/gold.png" alt="" width="100px" height="100px"></div>
                <div class="col s3"><img src="img/diamante.png" alt="" width="100px" height="100px"></div>
              </div>
              <ul id="tabs-swipe-demo" class="tabs">
                <li class="tab col s3" id="letra"><a href="#test1" class="active">Piedra</a></li>
                <li class="tab col s3" id="letra"><a href="#test2">Hierro</a></li>
                <li class="tab col s3" id="letra"><a href="#test3">Oro</a></li>
                <li class="tab col s3" id="letra"><a href="#test4">Diamante</a></li>
              </ul>
                <div id="test1" class="col s12">
                  <div class="row">
                    <p id="pMedallas" class="red-text" style="font-size: 30px;">Medallas de Piedra</p>
                    <p id="dMedallas" style="font-size: 25px;">Las medallas de piedra son las más fáciles de encontrar, manos a la obra.</p>
                    <br>
                    <div class="col l2 s3 push-l3 push-s1">
                      <img src="<?php if($_SESSION['p1'] == 1) {echo 'img/badges/p1.png';}else{echo 'img/blo.png';}
                        ?>" width="100%" height="100%">
                      
                    </div>
                    <div class="col l2 s3 push-l3 push-s1">
                      <img src="img/blo.png" width="100%" height="100%">
                    </div>
                    <div class="col l2 s3 push-l3 push-s1">
                      <img src="img/blo.png" width="100%" height="100%">
                    </div>
                  </div>
                </div>
                <div id="test2" class="col s12">
                  <p id="pMedallas" class="red-text" style="font-size: 30px;">Medallas de Hierro</p>
                  <p id="dMedallas" style="font-size: 25px;">Las medallas de hierro se suelen esconder pero siempre dejan rastro.</p>
                  <br>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                </div>
                <div id="test3" class="col s12">
                  <p id="pMedallas" class="red-text" style="font-size: 30px;">Medallas de Oro</p>
                  <p id="dMedallas" style="font-size: 25px;">Las medallas de oro son un poco difíciles de encontrar, quizá estén en el lugar que menos te lo pienses.</p>
                  <br>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                </div>
                <div id="test4" class="col s12">
                  <p id="pMedallas" class="red-text" style="font-size: 30px;">Medallas de Diamante</p>
                  <p id="dMedallas" style="font-size: 25px;">Las medallas de diamante son las mejores medallas que puedes tener pero no es nada fácil encontrarlas, unos dicen que son un mito, otros que nuna han existido. Nuestro consejo: Nunca te rindas.</p>
                  <br>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                  <div class="col l2 s3 push-l3 push-s1">
                    <img src="img/blo.png" width="100%" height="100%">
                  </div>
                </div>
            </div>
          </div>
        </div>
    </center>

<div id="modalmodifica" class="modal"> <!-- AREA DE MODIFICAR PERFIL -->
          <div class="modal-content">
          <form action="bd/update_pefil.php" method="POST">
            <center>
              <h4 id="modaltitu">Porque los cambios son buenos</h4>
              <p id="modaltexto"  class="center-align">Modifica tus datos</p>
              <p id="modaltexto" class="center-align">NOTA: Si no quieres modificar algún dato sólo déjalo en blanco</p>
              <input type="" name="aidi" style="display: none;" value=" <?php echo $userid1 ?>" >
                <div class="row">
                  <div class="input-field col s12 l4 push-l2">
                    <input id="nombre" type="text" class="validate" name="nombre">
                    <label for="last_name">Nombre</label>
                  </div>
                  <div class="input-field col s12 l4 push-l2">
                    <input id="nombre" type="text" class="validate" name="apellido">
                    <label for="last_name">Apellido</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12 l4 push-l1">
                    <input id="password" type="password" class="validate" name="passante">
                    <label for="password">Contraseña anterior</label>
                  </div>
                  <div class="input-field col s12 l3 push-l1">
                    <input id="password" type="password" class="validate" name="pass1">
                    <label for="password">Contraseña nueva</label>
                  </div>
                  <div class="input-field col s12 l3 push-l1">
                    <input id="password" type="password" class="validate" name="pass2">
                    <label for="password">Confirmar contraseña</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12 l10 push-l1">
                    <textarea id="textarea1" class="materialize-textarea" name="acerca"></textarea>
                    <label for="textarea1">Acerca de mi...</label>
                  </div>
                </div>
                <button class="btn waves-effect waves-light red lighten-1" type="submit" name="action">Modificar
                <i class="material-icons right">edit</i>
              </button>
            </center>
          </form>
          </div>
          <div class="modal-footer">
            <a class="modal-action modal-close waves-effect btn-flat">Cerrar</a>
          </div>
        </div>

  <div id="modalpago" class="modal">
    <div class="modal-content"><center>
      <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="FKGB3EWETLBNJ">
        <input type="image" src="https://www.paypalobjects.com/es_XC/MX/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal, la forma más segura y rápida de pagar en línea.">
        <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1">
        </form></center>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">atras</a>
    </div>
  </div>

<br><br>

  <?php 
    include 'footer-nav.php';
  ?>

  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
</body>
</html>
// Array de los componentes
// -------------------------
var arrayResStandard = new Array();
var arrayResStandardModello = [10,12,15,18,22,27,33,39,47,56,68,82];
var arrayVpower = ["V","negativo"];
var arrayWire = ["line-bot-dx","line-bot-sx","line-bot-sxdx","line-top-sx","line-top-dx","line-top-sxdx","line-v","line-v-sxdx","blank"];
var arrayLeds = ["led-green","led-red","led-white","led-yellow","led-blue"];
var cart = String.fromCharCode(109, 101, 100, 105, 97, 47);
var est = String.fromCharCode(46, 112, 110, 103);
var msg;
var vuoto = cart + "blank" + est;
var tabTrTdImg = "<td><img src='"+ vuoto + "' name=";

// Tabla campos calculados
// ------------------------
var table ="<br/><fieldset><legend>Resultados: </legend>";
table +="<table id = 'valOutput'><form name='output'><tr>";
table += "<td>V.led:</td><td><input type='text' name='Vled' size=8 onFocus='this.blur()'></td></tr>";
table += "<tr><td>V.Res.:</td><td><input type='text' name='Vres' size=8 onFocus='this.blur()'></td></tr>";
table += "<tr><td>Corriente: </td><td><input type='text' name='corrente' size=8 onFocus='this.blur()'></td></tr>";
table += "<tr><td>Resist.calc:</td><td><input type='text' name='resCalc' size=8 onFocus='this.blur()'></td></tr>";
table += "<tr><td>Resist.standard:</td><td><input type='text' name='resStandard' size=8 onFocus='this.blur()'></td></tr>";
table += "<tr><td>Pot.resist:</td><td><input type='text' id='potRes' name='potRes' size=8 onFocus='this.blur()'></td>";
table += "</tr></form></table></fieldset>";
table += "<fieldset><legend>Circuito Grafico</legend>";

// Tabla diseÃ±o circuito
// ----------------------
table += "<table id='circuito'>";
table += "<tr><td><div id = 'tensione'>+V</div></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y1'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y2'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y3'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y4'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y5'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y6'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y7'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y8'></td></tr>";
table += "<tr>" +tabTrTdImg + "'x2y9'></td></tr>";
table += "</table></fieldset>";

// Carga de las imagenes
// ----------------------------
var contatoreArrayRes = 0;

for (var indiceMultipl = 1; indiceMultipl <= 10000; indiceMultipl*= 10)
	{
	for (var indice in arrayResStandardModello)
		{
		arrayResStandard[contatoreArrayRes]= arrayResStandardModello[indice] * indiceMultipl;
		contatoreArrayRes++;
		}
	}

var imageResDB = new Array();
var imageLedDB = new Array();
var imageWireDB = new Array();
var imageVpowerDB = new Array();

for (var indice = 0; indice < arrayResStandard.length; indice++)
	{
	imageResDB[arrayResStandard[indice]] = new Image(75,75)
	imageResDB[arrayResStandard[indice]].src = cart + "R"+ arrayResStandard[indice] + est
	}

for (var indice = 0; indice < arrayLeds.length; indice++)
	{
	imageLedDB[arrayLeds[indice]] = new Image(75,75)
	imageLedDB[arrayLeds[indice]].src = cart + arrayLeds[indice] + est
	}

for (var indice = 0; indice < arrayWire.length; indice++)
	{
	imageWireDB[arrayWire[indice]] = new Image(75,75)
	imageWireDB[arrayWire[indice]].src = cart + arrayWire[indice] + est
	}

for (var indice = 0; indice < arrayVpower.length; indice++)
	{
	imageVpowerDB[arrayVpower[indice]] = new Image(75,75)
	imageVpowerDB[arrayVpower[indice]].src = cart + arrayVpower[indice] + est
	}	


// Calculo de la resistencia

function calcoloRes()
{
	var form = document.forms["input"];
	var Vled;
	var Vres;
	var resCalc;
	var valResStandard = -1; 
	var corrente;
	var potRes;
	var correnteTeorica = form.current.options[form.current.selectedIndex].value;
	var colorled = form.colorLeds.options[form.colorLeds.selectedIndex].value;
	var numLeds = form.numLeds.options[form.numLeds.selectedIndex].value;
	var Vpwr = form.tension.options[form.tension.selectedIndex].value;
	
// Tension de los leds en base a los colores

	switch (colorled) {
		case 'led-red': Vled = 1.8 * numLeds; break;
		case 'led-green': Vled = 2.1 * numLeds; break;
		case 'led-yellow': Vled = 2.1 * numLeds; break;
		case 'led-white': Vled = 3.6 * numLeds; break;
		case 'led-blue': Vled = 3.6 * numLeds; break;
	}

// 
	
	Vres = Vpwr - Vled;
	resCalc = Vres / correnteTeorica;
	if (resCalc > 0){
		valResStandard = Math.abs(trovaNumeroVicino(arrayResStandard, resCalc * 100) / 100); 
		corrente= Vres / valResStandard;
		potRes = Vres * corrente;
	
		document.forms["output"].Vled.value = Math.round(Vled * 100) / 100 + " V";
		document.forms["output"].Vres.value = Math.round(Vres * 100) / 100 + " V";
		document.forms["output"].resCalc.value = Math.round(resCalc * 100) / 100 + " ohms";
		document.forms["output"].resStandard.value = valResStandard + " ohms";
		document.forms["output"].corrente.value = Math.round(corrente * 1000)  + " mA";
		document.forms["output"].potRes.value = Math.round(potRes * 100) / 100 + " W";	

		if (potRes > 1) {
						document.forms["output"].potRes.style.backgroundColor = "#f80";
						}
		else if (potRes > 0.5) {	
						document.forms["output"].potRes.style.backgroundColor = "#fd0";
						}
		else {
						document.forms["output"].potRes.style.backgroundColor = "#eee";
						}
			
		
		document.x2y1.src = imageVpowerDB["V"].src;
		document.x2y2.src = imageResDB[Math.round(valResStandard * 100) + ""].src;
		document.x2y3.src = imageLedDB[colorled].src;
		document.getElementById("tensione").innerHTML = "+" + Vpwr + "V";
			
		switch (numLeds) {
			case "1":
					document.x2y4.src = imageVpowerDB["negativo"].src;
					document.x2y5.src = imageWireDB["blank"].src;
					document.x2y6.src = imageWireDB["blank"].src;
					document.x2y7.src = imageWireDB["blank"].src;				
					document.x2y8.src = imageWireDB["blank"].src;
					document.x2y9.src = imageWireDB["blank"].src;						
					break;
			case "2":
					document.x2y4.src = imageLedDB[colorled].src;
					document.x2y5.src = imageVpowerDB["negativo"].src;
					document.x2y6.src = imageWireDB["blank"].src;	
					document.x2y7.src = imageWireDB["blank"].src;				
					document.x2y8.src = imageWireDB["blank"].src;
					document.x2y9.src = imageWireDB["blank"].src;	
					break;
			case "3":
					document.x2y4.src = imageLedDB[colorled].src;
					document.x2y5.src = imageLedDB[colorled].src;
					document.x2y6.src = imageVpowerDB["negativ0"].src;
					document.x2y7.src = imageWireDB["blank"].src;				
					document.x2y8.src = imageWireDB["blank"].src;
					document.x2y9.src = imageWireDB["blank"].src;	
					break;
			case "4":
					document.x2y4.src = imageLedDB[colorled].src;
					document.x2y5.src = imageLedDB[colorled].src;
					document.x2y6.src = imageLedDB[colorled].src;					
					document.x2y7.src = imageVpowerDB["negativo"].src;
					document.x2y8.src = imageWireDB["blank"].src;
					document.x2y9.src = imageWireDB["blank"].src;					
					break;
			case "5":
					document.x2y4.src = imageLedDB[colorled].src;
					document.x2y5.src = imageLedDB[colorled].src;
					document.x2y6.src = imageLedDB[colorled].src;
					document.x2y7.src = imageLedDB[colorled].src;					
					document.x2y8.src = imageVpowerDB["negativo"].src;
					document.x2y9.src = imageWireDB["blank"].src;					
					break;
			case "6":
					document.x2y4.src = imageLedDB[colorled].src;
					document.x2y5.src = imageLedDB[colorled].src;
					document.x2y6.src = imageLedDB[colorled].src;
					document.x2y7.src = imageLedDB[colorled].src;
					document.x2y8.src = imageLedDB[colorled].src;
					document.x2y9.src = imageVpowerDB["negativo"].src;
					break;					
			}
		}
	else {
		document.forms["output"].Vled.value = "";
		document.forms["output"].Vres.value = "";
		document.forms["output"].resCalc.value = "";
		document.forms["output"].resStandard.value = "";
		document.forms["output"].corrente.value = "";
		document.forms["output"].potRes.value = "";		
		document.x2y1.src = imageWireDB["blank"].src;
		document.x2y2.src = imageWireDB["blank"].src;
		document.x2y3.src = imageWireDB["blank"].src;
		document.x2y4.src = imageWireDB["blank"].src;
		document.x2y5.src = imageWireDB["blank"].src;
		document.x2y6.src = imageWireDB["blank"].src;
		document.x2y7.src = imageWireDB["blank"].src;				
		document.x2y8.src = imageWireDB["blank"].src;
		document.x2y9.src = imageWireDB["blank"].src;		
		
		msg ="La tension de alimentacion es demasiado baja\n para alimentar los led elegidos.\n\n";
		window.alert(msg)
	}
}

function trovaNumeroVicino(my_array, valore){    
	var min_diff  = 9999999999999;
	var risultato = 0;
	var diff;
 
	for(var indice = 0; indice < my_array.length; indice++){
		diff = Math.abs(my_array[indice] - valore);
		if (diff == 0) {
			risultato = my_array[indice];
			break;
		}
		else if (diff < min_diff) {
			min_diff  = diff;
			risultato = my_array[indice];
		} 
	}
	return risultato;
} 
window.onload = calcoloRes;
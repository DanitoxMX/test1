<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <title>VydsLab</title>

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <link rel="stylesheet" type="text/css" href="css/tema.css">
  <link rel="stylesheet" type="text/css" href="css/registro.css">

  <link href="https://fonts.googleapis.com/css?family=Bubblegum+Sans" rel="stylesheet"> 
	
</head>
<body>
  
  <?php 
  include 'header-nav.php'; 
  ?>
	
	<div class="row">	
		<div class="col s12 #ef5350 z-depth-3" id="fondo1"><br>
      <center><span id="eslogan" class="white-text"><a class="white-text">Regístrate</a>
      </span></center>
      <a href="index.php"><span id="atras" class="white-text"><center>< Menú</center></span></a>
      <br>
		</div>
  </div>

  <br>

  <div class="row">

      <div class="col s10 l4 #ef5350 red lighten-1 push-l1 push-s1">
      <center>
        <p class="white-text" id="texto1">¡Sé parte de nuestra comunidad!</p>
        <p class="white-text" id="texto">VydsLab es la mejor y más completa herramienta que, junto con tu escuela, será un complemento clave para obtener el mayor aprendizaje posible.</p>
        <br><br><br><br><br><br><br>
      </center>
      </div>
      <div class="col s10 l6 push-l1 push-s1">
      <form action="bd/regist.php" method="POST">
        <div class="row">
          <div class="input-field col s6">
            <input id="nombre" type="text" class="validate" name="nombre">
            <label for="last_name">Nombre</label>
          </div>
          <div class="input-field col s6">
            <input id="apellido" type="text" class="validate" name="apellido">
            <label for="last_name">Apellido</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
            <input id="email" type="email" class="validate" name="email">
            <label for="email" data-error="ingrese un correo valido">Email</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s6">
            <input id="password" type="password" class="validate" name="pass1">
            <label for="password">Contraseña</label>
          </div>
          <div class="input-field col s6">
            <input id="password" type="password" class="validate" name="pass2">
            <label for="password">Confirmar contraseña</label>
          </div>
        </div>
        
        <div class="row">
          <div class="col s6">
            <center><p class="right-align">¿Tienes una tarjeta de regalo?</p></center>
          </div>
          <div class="input-field col s6">
            <i class="material-icons prefix">card_giftcard</i>
            <input id="icon_prefix" type="text" class="validate" name="codigo">
            <label for="icon_prefix">Ingresa tu código</label>
          </div>
        </div>

        <center><button class="btn waves-effect waves-light red lighten-1" type="submit" name="action">Registrarme
          <i class="material-icons right">send</i>
        </button></center>

        <br>

        <center><a class="modal-trigger" href="#modal2">¿Ya tienes una cuenta?</a></center>

        
      </form>
      </div>  
    </div>
  </div>
    
        <div id="modal2" class="modal">
          <div class="modal-content">
					<form action="bd/login.php" method="POST">
            <center>
              <h4 id="modaltitu">Nos alegra que vuelvas :D</h4>
              <p id="modaltexto"  class="center-align">Sabíamos que regresarías, sigue disfrutando de nuestra web</p>
              <div class="row">
                <div class="input-field col s12 l6 push-l3">
                  <input id="email" type="email" class="validate" name="email">
                  <label for="email" data-error="ingrese un correo valido">Email</label>
                </div>
              </div>
              <div class="row">
                <div class="input-field col s12 l6 push-l3">
                  <input id="password" type="password" class="validate" name="pass">
                  <label for="password">Contraseña</label>
                </div>
              </div>
              <button class="btn waves-effect waves-light red lighten-1" type="submit" name="action">Iniciar Sesión
                <i class="material-icons right">send</i>
              </button>
            </center>
					</form>
          </div>
          <div class="modal-footer">
            <a class="modal-action modal-close waves-effect btn-flat">Cerrar</a>
          </div>
        </div>

<br>

  <?php 
    include 'footer-nav.php';
  ?>

  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>
</body>
</html>
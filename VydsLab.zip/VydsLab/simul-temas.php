<head>
	 <link rel="stylesheet" type="text/css" href="css/tema.css">
</head>
<body>
	<h3 ><a href="simul-home.php" class="#ef5350-text" id="titleright">Simulación</a></h3>
    <ul>
		<a href="" class="teal-text"><li id="subtright">Números aleatorios</li></a>
        <a href="" class="teal-text"><li id="subtright">Números aleatorios</li></a>
        <a href="" class="teal-text"><li id="subtright">Azuquitar</li></a>
        <a href="" class="teal-text"><li id="subtright">Números aleatorios</li></a>
        <a href="" class="teal-text"><li id="subtright">Números aleatorios</li></a>
    </ul>
</body>
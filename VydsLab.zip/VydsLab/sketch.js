function setup() {
	createCanvas(600, 600);	
}

function draw() {
	background(0);
	stroke(255);
	
	//Cabeza
	ellipse(300, 200, 100, 100);
	fill(0);
	ellipse(280, 180, 10, 10);
	ellipse(320, 180, 10, 10);
	arc(300, 330, 60, 60, 0, PI);
	
	fill(255);
	
	
	//Cuello
	line(300, 250, 300, 300);
	
	//Cuerpo
	quad(250, 300, 350, 300, 370, 500, 230, 500);
	
	//Pies
	rect(250, 500, 10, 80);
	rect(340, 500, 10, 80);
	
	//Manos
	triangle(245, 350, 210, 350, 180, 320);
	triangle(350, 350, 400, 350, 450, 320);
}